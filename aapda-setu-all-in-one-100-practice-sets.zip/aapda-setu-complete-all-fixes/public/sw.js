/* Aapda Setu offline-first shell. Never cache API, account-verification, or cross-origin responses. */
const CACHE_PREFIX = 'aapda-shell-'
const CACHE = `${CACHE_PREFIX}v4`
const OFFLINE_URL = '/offline.html'
// Pre-cache every core app route so Saath, Pukar, practice, contacts, profile and
// readiness tools can open offline after the first successful online visit/install.
// These routes are client-rendered; sensitive verification/API paths are excluded below.
const APP_ROUTES = ['/', '/monitor', '/saath', '/rescue', '/alerts', '/practice', '/journey', '/contacts', '/profile']
const CORE_URLS = [OFFLINE_URL, '/favicon.svg', '/aapda-setu-logo.png', '/manifest.webmanifest', ...APP_ROUTES]
const NEVER_CACHE = [/^\/api(?:\/|$)/, /^\/verify-email(?:\/|$)/, /^\/\.netlify(?:\/|$)/]

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE)
    await Promise.allSettled(CORE_URLS.map(async (url) => {
      const response = await fetch(url, { cache: 'reload', credentials: 'same-origin' })
      if (response.ok && response.type === 'basic') await cache.put(url, response)
    }))
    await self.skipWaiting()
  })())
})

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys()
    await Promise.all(keys.filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE).map((key) => caches.delete(key)))
    await self.clients.claim()
  })())
})

function isSensitivePath(pathname) {
  return NEVER_CACHE.some((pattern) => pattern.test(pathname))
}

self.addEventListener('fetch', (event) => {
  const request = event.request
  if (request.method !== 'GET') return
  const url = new URL(request.url)
  if (url.origin !== self.location.origin || isSensitivePath(url.pathname)) return

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE)
      try {
        const response = await fetch(request)
        if (response.ok && response.type === 'basic') {
          // Cache only the app's HTML shell/routes, never verification or API pages.
          await cache.put(request, response.clone())
        }
        return response
      } catch {
        const cachedPage = await cache.match(request, { ignoreSearch: true })
        if (cachedPage) return cachedPage
        // Every app route is client-rendered. Reuse a cached app shell for a route
        // that was not individually cached, then let the router render the URL.
        const shell = await cache.match('/monitor') || await cache.match('/')
        return shell || await cache.match(OFFLINE_URL) || Response.error()
      }
    })())
    return
  }

  // Cache-first for same-origin build assets and public static files. Network refreshes
  // the cache in the background so subsequent launches can work without connectivity.
  if (['script', 'style', 'font', 'image', 'audio', 'worker'].includes(request.destination) ||
      /\.(?:js|css|json|svg|png|jpe?g|webp|ico|woff2?|ttf|wav|webmanifest)$/i.test(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE)
      const cached = await cache.match(request)
      if (cached) return cached
      try {
        const response = await fetch(request)
        if (response.ok && response.type === 'basic') await cache.put(request, response.clone())
        return response
      } catch {
        return Response.error()
      }
    })())
  }
})
