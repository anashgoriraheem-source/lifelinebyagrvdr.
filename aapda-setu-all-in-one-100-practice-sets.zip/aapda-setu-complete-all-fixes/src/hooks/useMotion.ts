import { useCallback, useEffect, useRef, useState } from 'react'
import { createFallDetector, type FallEvent, type Sensitivity } from '@/lib/fallDetection'

type MotionPermission = 'unknown' | 'granted' | 'denied' | 'unsupported'

/** Phone motion sensor diagnostics + fall/jolt heuristic. This only runs while the page is open. */
export function useMotion(onEvent: (e: FallEvent) => void, sensitivity: Sensitivity = 'medium') {
  const [permission, setPermission] = useState<MotionPermission>('unknown')
  const [magnitude, setMagnitude] = useState<number | null>(null)
  const [checking, setChecking] = useState<number | null>(null)
  const [sensorActive, setSensorActive] = useState(false)
  const [sensorError, setSensorError] = useState<string | null>(null)
  const cb = useRef(onEvent)
  cb.current = onEvent
  const wakeLock = useRef<{ release(): Promise<void> } | null>(null)

  useEffect(() => {
    if (typeof window === 'undefined' || !('DeviceMotionEvent' in window)) {
      setPermission('unsupported')
      setSensorError('This browser does not expose the phone motion sensor. Try Chrome on Android over HTTPS.')
    }
  }, [])

  useEffect(() => {
    if (permission !== 'granted') return
    const feed = createFallDetector(sensitivity)
    let lastUi = 0
    let gotSample = false
    const noSampleTimer = window.setTimeout(() => {
      if (!gotSample) {
        setSensorActive(false)
        setSensorError('Permission was granted, but no motion readings arrived. Open this page directly in Chrome/Safari, allow motion sensors, and keep the page visible.')
      }
    }, 2500)
    const handler = (ev: DeviceMotionEvent) => {
      // Some devices only populate `acceleration`; others populate `accelerationIncludingGravity`.
      const a = ev.accelerationIncludingGravity ?? ev.acceleration
      if (!a || a.x == null || a.y == null || a.z == null) return
      const mag = Math.hypot(a.x, a.y, a.z)
      if (!Number.isFinite(mag)) return
      gotSample = true
      window.clearTimeout(noSampleTimer)
      setSensorActive(true)
      setSensorError(null)
      const now = performance.now()
      if (now - lastUi > 150) {
        setMagnitude(mag)
        lastUi = now
      }
      const e = feed(mag, now)
      if (!e) return
      if (e.type === 'checking') setChecking(Math.ceil(e.remainingMs / 1000))
      else {
        setChecking(e.type === 'impact' ? 10 : null)
        cb.current(e)
      }
    }
    window.addEventListener('devicemotion', handler, { passive: true })
    const nav = navigator as Navigator & { wakeLock?: { request(t: 'screen'): Promise<{ release(): Promise<void> }> } }
    nav.wakeLock?.request('screen').then((l) => (wakeLock.current = l)).catch(() => {})
    return () => {
      window.clearTimeout(noSampleTimer)
      window.removeEventListener('devicemotion', handler)
      void wakeLock.current?.release()
      wakeLock.current = null
    }
  }, [permission, sensitivity])

  const enable = useCallback(async () => {
    if (typeof window === 'undefined') return
    const DM = window.DeviceMotionEvent as (typeof DeviceMotionEvent & { requestPermission?: () => Promise<'granted' | 'denied'> }) | undefined
    if (!DM) {
      setPermission('unsupported')
      setSensorError('This browser does not support DeviceMotionEvent. Try the latest Chrome or Safari over HTTPS.')
      return
    }
    setMagnitude(null)
    setSensorActive(false)
    setSensorError(null)
    try {
      if (typeof DM.requestPermission === 'function') {
        const result = await DM.requestPermission()
        if (result !== 'granted') {
          setPermission('denied')
          setSensorError('Motion permission was denied. Allow motion access in your browser/device settings and try again.')
          return
        }
      }
      setPermission('granted')
    } catch (error) {
      setPermission('denied')
      setSensorError(error instanceof Error ? error.message : 'Motion permission could not be requested. Open the page directly over HTTPS and try again.')
    }
  }, [])

  return { permission, magnitude, checking, sensorActive, sensorError, enable }
}
