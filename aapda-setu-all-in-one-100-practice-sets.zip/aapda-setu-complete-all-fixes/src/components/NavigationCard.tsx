import { useState } from 'react'
import { ArrowRight, Building2, Bus, Fuel, GraduationCap, Hospital, Landmark, MapPin, Navigation, Pill, Search, Shield, TrainFront, Route as RouteIcon, Flame, Hotel } from 'lucide-react'
import { useApp } from '@/hooks/useApp'

type Place = { place_id?: number; display_name: string; lat: string; lon: string; type?: string; category?: string }
type RouteInfo = { distance: number; duration: number }

type SearchCategory = { aliases: string[]; selectors: Array<[string, string]> }
const SEARCH_CATEGORIES: Record<string, SearchCategory> = {
  hospital: { aliases: ['hospital', 'hospitals'], selectors: [['amenity', 'hospital']] },
  'police station': { aliases: ['police', 'police station', 'police stations'], selectors: [['amenity', 'police']] },
  'fire station': { aliases: ['fire station', 'fire stations'], selectors: [['amenity', 'fire_station']] },
  'petrol pump': { aliases: ['petrol pump', 'petrol pumps', 'fuel station', 'fuel stations', 'petrol station', 'fuel station petrol station'], selectors: [['amenity', 'fuel']] },
  court: { aliases: ['court', 'courts', 'courthouse', 'courthouses'], selectors: [['amenity', 'courthouse']] },
  'bus station': { aliases: ['bus station', 'bus stations', 'bus stand', 'bus stands', 'bus terminal'], selectors: [['amenity', 'bus_station'], ['highway', 'bus_stop']] },
  'railway station': { aliases: ['railway station', 'railway stations', 'train station', 'train stations'], selectors: [['railway', 'station'], ['railway', 'halt']] },
  pharmacy: { aliases: ['pharmacy', 'pharmacies', 'chemist', 'medical store', 'medical stores'], selectors: [['amenity', 'pharmacy']] },
  school: { aliases: ['school', 'schools'], selectors: [['amenity', 'school'], ['building', 'school']] },
  college: { aliases: ['college', 'colleges'], selectors: [['amenity', 'college']] },
  university: { aliases: ['university', 'universities'], selectors: [['amenity', 'university']] },
  'shopping mall': { aliases: ['shopping mall', 'shopping malls', 'mall', 'malls'], selectors: [['shop', 'mall']] },
  supermarket: { aliases: ['supermarket', 'supermarkets', 'mart', 'marts', 'grocery store', 'grocery stores', 'supermarket mart grocery store', 'marts & supermarkets'], selectors: [['shop', 'supermarket'], ['shop', 'convenience']] },
  hotel: { aliases: ['hotel', 'hotels'], selectors: [['tourism', 'hotel'], ['tourism', 'motel']] },
  landmark: { aliases: ['landmark', 'landmarks', 'important landmark', 'important landmarks'], selectors: [['tourism', 'attraction'], ['historic', '*']] },
}

function normalizeCategory(term: string): string | null {
  const cleaned = term.toLowerCase().trim().replace(/\bnear me\b/g, '').replace(/\bnearby\b/g, '').replace(/\s+/g, ' ').trim()
  return Object.entries(SEARCH_CATEGORIES).find(([, item]) => item.aliases.includes(cleaned))?.[0] ?? null
}

async function geocodeOrigin(origin: string): Promise<{ lat: number; lng: number } | null> {
  const url = new URL('https://nominatim.openstreetmap.org/search')
  url.searchParams.set('q', origin)
  url.searchParams.set('format', 'jsonv2')
  url.searchParams.set('limit', '1')
  const response = await fetch(url.toString(), { headers: { Accept: 'application/json' } })
  if (!response.ok) return null
  const results = await response.json() as Array<{ lat: string; lon: string }>
  return results[0] ? { lat: Number(results[0].lat), lng: Number(results[0].lon) } : null
}

async function searchNearbyCategory(categoryKey: string, center: { lat: number; lng: number }): Promise<Place[]> {
  const category = SEARCH_CATEGORIES[categoryKey]
  if (!category) return []
  const selectors = category.selectors.map(([key, value]) => {
    const tag = value === '*' ? `["${key}"]` : `["${key}"="${value}"]`
    return `node(around:12000,${center.lat},${center.lng})${tag};way(around:12000,${center.lat},${center.lng})${tag};relation(around:12000,${center.lat},${center.lng})${tag};`
  }).join('')
  const query = `[out:json][timeout:20];(${selectors});out center;`
  const endpoints = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter']
  let lastError: unknown
  for (const endpoint of endpoints) {
    try {
      const response = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=UTF-8', Accept: 'application/json' }, body: query })
      if (!response.ok) throw new Error('Nearby places service is busy. Please retry in a moment.')
      const payload = await response.json() as { elements?: Array<{ id: number; type: string; lat?: number; lon?: number; center?: { lat: number; lon: number }; tags?: Record<string, string> }> }
      const seen = new Set<string>()
      return (payload.elements ?? []).flatMap((el) => {
        const lat = el.lat ?? el.center?.lat
        const lon = el.lon ?? el.center?.lon
        if (lat == null || lon == null) return []
        const tags = el.tags ?? {}
        const name = tags.name || tags['name:en'] || tags.brand || tags.operator
        const address = [tags['addr:housenumber'], tags['addr:street'], tags['addr:suburb'] || tags['addr:neighbourhood'], tags['addr:city']].filter(Boolean).join(', ')
        const displayName = [name || `Unnamed ${categoryKey}`, address || tags['addr:city']].filter(Boolean).join(' · ')
        const unique = `${displayName.toLowerCase()}|${Number(lat).toFixed(5)}|${Number(lon).toFixed(5)}`
        if (seen.has(unique)) return []
        seen.add(unique)
        return [{ place_id: el.id, display_name: displayName, lat: String(lat), lon: String(lon), type: categoryKey, category: el.type }]
      })
    } catch (error) { lastError = error }
  }
  throw lastError instanceof Error ? lastError : new Error('Nearby places search failed. Try again or use a full place name.')
}

const CATEGORIES = [
  { label: 'Hospitals', query: 'hospital', icon: Hospital },
  { label: 'Police', query: 'police station', icon: Shield },
  { label: 'Fire stations', query: 'fire station', icon: Flame },
  { label: 'Petrol pumps', query: 'petrol pump', icon: Fuel },
  { label: 'Courts', query: 'court', icon: Landmark },
  { label: 'Bus stands', query: 'bus station', icon: Bus },
  { label: 'Railway stations', query: 'railway station', icon: TrainFront },
  { label: 'Pharmacies', query: 'pharmacy', icon: Pill },
  { label: 'Schools', query: 'school', icon: GraduationCap },
  { label: 'Colleges', query: 'college', icon: GraduationCap },
  { label: 'Universities', query: 'university', icon: GraduationCap },
  { label: 'Landmarks', query: 'important landmark', icon: MapPin },
  { label: 'Malls', query: 'shopping mall', icon: Building2 },
  { label: 'Marts & supermarkets', query: 'supermarket mart grocery store', icon: Building2 },
  { label: 'Major hotels', query: 'hotel', icon: Hotel },
]

export function NavigationCard() {
  const fix = useApp((s) => s.location.fix)
  const [query, setQuery] = useState('')
  const [origin, setOrigin] = useState('')
  const [places, setPlaces] = useState<Place[]>([])
  const [selected, setSelected] = useState<Place | null>(null)
  const [route, setRoute] = useState<RouteInfo | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function searchPlaces(text = query) {
    const term = text.trim()
    if (!term) { setError('Enter a school name, category, city, address or landmark to search.'); return }
    setBusy(true); setError(''); setRoute(null); setSelected(null); setPlaces([])
    try {
      const categoryKey = normalizeCategory(term)
      if (categoryKey) {
        let center = fix ? { lat: fix.lat, lng: fix.lng } : null
        if (!center && origin.trim()) center = await geocodeOrigin(origin.trim())
        if (!center) {
          setError('To list nearby places, enable GPS or enter a starting city/area below.')
          return
        }
        const found = await searchNearbyCategory(categoryKey, center)
        const distance = (p: Place) => {
          const lat = Number(p.lat) * Math.PI / 180
          const dLat = Number(p.lat) - center!.lat
          const dLng = (Number(p.lon) - center!.lng) * Math.cos(center!.lat * Math.PI / 180)
          return Math.hypot(dLat, dLng)
        }
        const sorted = found.sort((a, b) => distance(a) - distance(b))
        setPlaces(sorted.slice(0, 100))
        if (!sorted.length) setError(`No mapped ${categoryKey} places were found within about 12 km. Try a wider area or search by name.`)
        return
      }

      // Free-text search remains a geocoder search for named places, addresses and landmarks.
      const url = new URL('https://nominatim.openstreetmap.org/search')
      url.searchParams.set('q', fix && !origin.trim() ? term : (origin.trim() && !fix ? `${term}, ${origin.trim()}` : term))
      url.searchParams.set('format', 'jsonv2')
      url.searchParams.set('limit', '20')
      url.searchParams.set('addressdetails', '1')
      if (fix) {
        const span = 0.35
        url.searchParams.set('viewbox', `${fix.lng-span},${fix.lat+span},${fix.lng+span},${fix.lat-span}`)
        url.searchParams.set('bounded', '0')
      }
      const response = await fetch(url.toString(), { headers: { Accept: 'application/json' } })
      if (!response.ok) throw new Error('Place search is temporarily unavailable. Please try again.')
      const data = await response.json() as Place[]
      const sorted = fix ? [...data].sort((a, b) => {
        const dist = (p: Place) => Math.hypot(Number(p.lat) - fix.lat, (Number(p.lon) - fix.lng) * Math.cos(fix.lat * Math.PI / 180))
        return dist(a) - dist(b)
      }) : data
      setPlaces(sorted.slice(0, 20))
      if (!data.length) setError('No matching places found. Try the exact place name or add a city/area.')
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not search right now.') }
    finally { setBusy(false) }
  }

  async function chooseDestination(place: Place) {
    setSelected(place); setPlaces([]); setRoute(null); setError('')
    if (!fix) return
    try {
      const url = `https://router.project-osrm.org/route/v1/driving/${fix.lng},${fix.lat};${place.lon},${place.lat}?overview=false`
      const response = await fetch(url)
      if (!response.ok) throw new Error('Route preview is unavailable right now.')
      const data = await response.json()
      const r = data.routes?.[0]
      if (r) setRoute({ distance: r.distance, duration: r.duration })
      else setError('No driving route found. You can still open directions in Google Maps.')
    } catch { setError('Could not calculate an in-app route preview. You can still open directions in Google Maps.') }
  }

  const originParam = fix ? `${fix.lat},${fix.lng}` : origin.trim()
  const googleUrl = selected
    ? `https://www.google.com/maps/dir/?api=1&${originParam ? `origin=${encodeURIComponent(originParam)}&` : ''}destination=${encodeURIComponent(`${selected.lat},${selected.lon}`)}&travelmode=driving`
    : ''
  const openMapUrl = selected
    ? `https://www.openstreetmap.org/?mlat=${selected.lat}&mlon=${selected.lon}#map=13/${selected.lat}/${selected.lon}`
    : ''

  return (
    <article className="overflow-hidden rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200 sm:p-6">
      <div className="flex items-center gap-2">
        <span className="grid size-9 place-items-center rounded-xl bg-sky-50 text-sky-700"><Navigation className="size-4" /></span>
        <div><h2 className="font-display text-lg font-bold text-slate-900">Search & navigate</h2><p className="text-xs text-slate-500">Find nearby essentials or search any destination</p></div>
      </div>
      <form className="mt-4 flex gap-2" onSubmit={(e) => { e.preventDefault(); void searchPlaces() }}>
        <div className="relative min-w-0 flex-1"><Search className="absolute left-3 top-3 size-4 text-slate-400"/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="City, address, hospital, landmark…" className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-sm outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-100" aria-label="Search any destination" /></div>
        <button type="submit" disabled={busy} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-bold text-white disabled:opacity-60">{busy ? 'Searching…' : 'Search'}</button>
      </form>
      {!fix && <label className="mt-3 block text-xs text-slate-600">Starting point (or enable live GPS above)<input value={origin} onChange={(e) => setOrigin(e.target.value)} placeholder="e.g. Rohtak, Haryana" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-sky-500" /></label>}
      <p className="mt-2 text-[11px] text-slate-500">Nearby categories list mapped places within about 12 km, closest first. Named-place searches use OpenStreetMap geocoding.</p>
      <div className="mt-2 flex gap-2 overflow-x-auto pb-2">
        {CATEGORIES.map((c) => { const Icon = c.icon; return <button type="button" key={c.label} onClick={() => { setQuery(c.query); void searchPlaces(c.query) }} className="flex shrink-0 items-center gap-1.5 rounded-full bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-sky-50 hover:text-sky-800"><Icon className="size-3.5"/>{c.label}</button> })}
      </div>
      {error && <p role="status" className="mt-3 rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-900">{error}</p>}
      {places.length > 0 && <div className="mt-3 max-h-96 overflow-y-auto divide-y divide-slate-100 rounded-2xl border border-slate-200"><p className="sticky top-0 z-10 bg-white px-3 py-2 text-xs font-semibold text-slate-500">Showing {places.length} result{places.length === 1 ? '' : 's'} · select one for directions</p>{places.map((p, i) => <button key={`${p.place_id ?? p.lat}-${p.lon}-${i}`} onClick={() => void chooseDestination(p)} className="flex w-full items-start gap-3 p-3 text-left hover:bg-slate-50"><MapPin className="mt-0.5 size-4 shrink-0 text-sky-600"/><span className="text-sm text-slate-700">{p.display_name}</span><ArrowRight className="ml-auto mt-0.5 size-4 shrink-0 text-slate-400"/></button>)}</div>}
      {selected && <div className="mt-4 overflow-hidden rounded-2xl border border-slate-200">
        <div className="flex items-start gap-3 p-4"><span className="grid size-9 shrink-0 place-items-center rounded-xl bg-emerald-50 text-emerald-700"><MapPin className="size-4"/></span><div className="min-w-0 flex-1"><h3 className="text-sm font-bold text-slate-900">Destination selected</h3><p className="mt-1 text-xs leading-relaxed text-slate-600">{selected.display_name}</p>{route && <p className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-slate-800"><RouteIcon className="size-4"/>{(route.distance / 1000).toFixed(1)} km · about {Math.max(1, Math.round(route.duration / 60))} min by road</p>}<p className="mt-2 text-[11px] text-slate-500">Turn-by-turn guidance opens in Google Maps. Route estimates can change with traffic and road conditions.</p></div></div>
        <div className="grid grid-cols-2 gap-2 p-3 pt-0"><a href={googleUrl} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-xl bg-sky-700 px-3 py-3 text-center text-xs font-bold text-white"><Navigation className="size-4"/>Start navigation</a><a href={openMapUrl} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 px-3 py-3 text-center text-xs font-bold text-slate-700">View map</a></div>
      </div>}
      <p className="mt-3 text-[10px] leading-relaxed text-slate-400">Nearby category searches are bounded around your GPS location when available. Nearby category search uses OpenStreetMap data via Overpass; named-place search uses Nominatim; route previews use the public OSRM demo service. These services have usage limits and are not guaranteed for emergency-critical navigation. Google Maps opens for turn-by-turn guidance.</p>
    </article>
  )
}
