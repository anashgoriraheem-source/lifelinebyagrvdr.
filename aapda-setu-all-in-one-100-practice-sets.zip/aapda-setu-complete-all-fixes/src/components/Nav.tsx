import { Link } from '@tanstack/react-router'
import { HeartPulse, Languages, ChevronDown } from 'lucide-react'
import { useEffect, useState } from 'react'
import { LANGUAGE_GROUPS, type LanguageCode } from '@/lib/i18n'
import { useApp } from '@/hooks/useApp'

export function Nav() {
  const [language, setLanguage] = useState<LanguageCode>('en')
  const [languageMenu, setLanguageMenu] = useState<'choose' | 'national' | 'international' | null>(null)
  useEffect(() => { try { const saved = localStorage.getItem('lifeline-language'); const supported = LANGUAGE_GROUPS.some(group => group.items.some(([code]) => code === saved)); if (supported && saved) setLanguage(saved as LanguageCode) } catch { /* language choice remains English for this session */ } }, [])
  const chooseLanguage = (code: LanguageCode) => { setLanguage(code); try { localStorage.setItem('lifeline-language', code) } catch { /* language choice remains for this session */ } setLanguageMenu(null); window.dispatchEvent(new Event('lifeline-language-change')) }
  const demo = useApp((s) => s.demoMode)
  const alarm = useApp((s) => s.alarm.phase)
  const hasVitals = useApp((s) => Object.keys(s.vitals).length > 0)

  const pill =
    alarm !== 'idle'
      ? { text: 'Alarm', cls: 'bg-rose-600 text-white', dot: 'bg-white animate-flash' }
      : demo
        ? { text: 'Demo', cls: 'bg-amber-100 text-amber-900', dot: 'bg-amber-500' }
        : hasVitals
          ? { text: 'Guarding', cls: 'bg-emerald-50 text-emerald-800', dot: 'bg-emerald-500' }
          : { text: 'No device', cls: 'bg-slate-100 text-slate-600', dot: 'bg-slate-400' }

  const link = 'px-3 py-2 rounded-xl text-[12px] font-semibold tracking-wide text-slate-400 hover:text-amber-200 hover:bg-white/5 transition whitespace-nowrap'
  const active = { className: `${link} !bg-amber-300/10 !text-amber-200 ring-1 ring-amber-300/25` }

  return (
    <header className="sticky top-0 z-30 border-b border-amber-300/15 bg-slate-950/90 backdrop-blur-xl shadow-[0_8px_30px_rgba(0,0,0,.25)]">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        <Link to="/" className="mr-auto flex items-center gap-2">
          <span className="grid size-10 place-items-center rounded-2xl border border-amber-200/30 bg-gradient-to-br from-amber-200 to-amber-500 text-slate-950 shadow-lg shadow-amber-500/15">
            <HeartPulse className="size-4.5" strokeWidth={2.5} />
          </span>
          <span className="font-display text-lg font-extrabold tracking-tight text-white">Aapda <span className="text-amber-300">Setu</span></span>
        </Link>
        <nav className="flex max-w-[52vw] items-center gap-1 overflow-x-auto sm:max-w-none">
          <Link to="/monitor" className={link} activeProps={active}>Monitor</Link>
          <Link to="/saath" className={link} activeProps={active}>Saath</Link>
          <Link to="/rescue" className={link} activeProps={active}>Rescue</Link>
          <Link to="/journey" className={link} activeProps={active}>Journey</Link>
          <Link to="/alerts" className={link} activeProps={active}>Alerts</Link>
          <Link to="/practice" className={link} activeProps={active}>Practice</Link>
          <Link to="/contacts" className={link} activeProps={active}>Contacts</Link>
        </nav>
        <div className="relative">
          <button type="button" onClick={() => setLanguageMenu(languageMenu ? null : 'choose')} aria-expanded={Boolean(languageMenu)} className="flex items-center gap-1.5 rounded-xl border border-amber-300/20 bg-white/5 px-3 py-2 text-xs font-semibold text-amber-100 hover:bg-amber-300/10" aria-label="Choose language">
            <Languages className="size-4" /><span className="hidden sm:inline">Choose language</span><ChevronDown className="size-3" />
          </button>
          {languageMenu && <div className="absolute right-0 top-full z-50 mt-2 w-64 rounded-2xl border border-amber-300/20 bg-[#11151e] p-3 shadow-2xl">
            <p className="px-2 pb-2 text-sm font-bold">Choose language</p>
            <div className="grid grid-cols-2 gap-2">
              {LANGUAGE_GROUPS.map(group => <button key={group.id} type="button" onClick={() => setLanguageMenu(group.id)} className={`rounded-xl px-2 py-2 text-left text-xs font-semibold ${languageMenu === group.id ? 'bg-amber-300/15 text-amber-100' : 'bg-white/5 text-slate-300 hover:bg-white/10'}`}>{group.id === 'national' ? '🇮🇳 National languages' : '🌐 International languages'}</button>)}
            </div>
            {LANGUAGE_GROUPS.filter(group => group.id === languageMenu).map(group => <div key={group.id} className="mt-3 grid max-h-64 grid-cols-2 gap-1 overflow-y-auto">
              {group.items.map(([code, native, english]) => <button key={code} type="button" onClick={() => chooseLanguage(code as LanguageCode)} className={`rounded-lg px-2 py-2 text-left text-sm hover:bg-rose-50 ${language === code ? 'bg-amber-300/10 font-bold text-amber-200 ring-1 ring-amber-300/25' : 'text-slate-300'}`}><span className="block">{native}</span><span className="block text-[10px] text-slate-400">{english}</span></button>)}
            </div>)}
          </div>}
        </div>
        <span className={`ml-1 hidden items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold sm:flex ${pill.cls}`}>
          <span className={`size-1.5 rounded-full ${pill.dot}`} />
          {pill.text}
        </span>
      </div>
    </header>
  )
}
