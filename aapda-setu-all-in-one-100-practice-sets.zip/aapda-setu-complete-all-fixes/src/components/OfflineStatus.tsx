import { useEffect, useRef, useState } from 'react'
import { Wifi, WifiOff } from 'lucide-react'

export function OfflineStatus() {
  const [online, setOnline] = useState(() => typeof navigator === 'undefined' ? true : navigator.onLine)
  const [showOnline, setShowOnline] = useState(false)
  const onlineTimer = useRef<number | null>(null)

  useEffect(() => {
    const goOnline = () => {
      setOnline(true)
      setShowOnline(true)
      if (onlineTimer.current !== null) window.clearTimeout(onlineTimer.current)
      onlineTimer.current = window.setTimeout(() => setShowOnline(false), 4500)
    }
    const goOffline = () => { setOnline(false); setShowOnline(false) }
    window.addEventListener('online', goOnline)
    window.addEventListener('offline', goOffline)
    return () => {
      window.removeEventListener('online', goOnline)
      window.removeEventListener('offline', goOffline)
      if (onlineTimer.current !== null) window.clearTimeout(onlineTimer.current)
    }
  }, [])

  if (online && !showOnline) return null

  return (
    <div role="status" aria-live="polite" className={`px-4 py-2 text-center text-xs font-semibold ${online ? 'bg-emerald-950 text-emerald-100' : 'bg-amber-950 text-amber-100'}`}>
      <span className="inline-flex items-center justify-center gap-2">
        {online ? <Wifi className="size-4" /> : <WifiOff className="size-4" />}
        {online
          ? 'Connection restored. Some live features may need refreshing.'
          : 'OFFLINE MODE · Saved guidance and previously loaded screens may work. Live maps, cloud services and message delivery are unavailable or unconfirmed.'}
      </span>
    </div>
  )
}
