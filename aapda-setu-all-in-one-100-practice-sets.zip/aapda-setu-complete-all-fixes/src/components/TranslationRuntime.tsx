import { useEffect } from 'react'
import { translateText, type LanguageCode } from '@/lib/i18n'

const KEY = 'lifeline-language'
const RTL_LANGUAGES = new Set<LanguageCode>(['ar', 'ur'])
const ORIGINAL_TITLE = 'Aapda Setu — emergency support'

/**
 * Keep original React-authored text separately from the translated display text.
 * This lets language changes switch directly between languages instead of
 * translating an already translated string. React updates are detected too.
 */
export function TranslationRuntime() {
  useEffect(() => {
    const originals = new WeakMap<Text, string>()
    const rendered = new WeakMap<Text, string>()
    const originalAttrs = new WeakMap<Element, Map<string, string>>()
    const renderedAttrs = new WeakMap<Element, Map<string, string>>()
    let scheduled = false

    const getLang = (): LanguageCode => {
      try { const saved = localStorage.getItem(KEY) as LanguageCode | null; return saved || 'en' } catch { return 'en' }
    }

    const shouldSkip = (node: Text) => {
      const parent = node.parentElement
      if (!parent) return true
      return Boolean(parent.closest('script, style, noscript, code, pre, textarea, [data-no-translate]'))
    }

    const apply = () => {
      scheduled = false
      const lang = getLang()
      document.documentElement.lang = lang
      document.documentElement.dir = RTL_LANGUAGES.has(lang) ? 'rtl' : 'ltr'
      document.title = lang === 'en' ? ORIGINAL_TITLE : translateText(ORIGINAL_TITLE, lang)

      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT)
      const nodes: Text[] = []
      while (walker.nextNode()) nodes.push(walker.currentNode as Text)

      for (const node of nodes) {
        if (shouldSkip(node)) continue
        const current = node.nodeValue || ''
        const previousDisplay = rendered.get(node)
        let original = originals.get(node)
        // React may have replaced the text content of an existing text node.
        if (original === undefined || (previousDisplay !== undefined && current !== previousDisplay)) {
          original = current
          originals.set(node, original)
        }
        const translated = lang === 'en' ? original : translateText(original, lang)
        rendered.set(node, translated)
        if (current !== translated) node.nodeValue = translated
      }

      document.querySelectorAll<HTMLElement>('[placeholder], [aria-label], [aria-description], [title], [alt], meta[name="description"], meta[property="og:description"]').forEach(el => {
        const attrs = ['placeholder', 'aria-label', 'aria-description', 'title', 'alt', ...(el instanceof HTMLMetaElement ? ['content'] : [])]
        let saved = originalAttrs.get(el)
        let last = renderedAttrs.get(el)
        if (!saved) { saved = new Map(); originalAttrs.set(el, saved) }
        if (!last) { last = new Map(); renderedAttrs.set(el, last) }
        for (const attr of attrs) {
          const current = el.getAttribute(attr)
          if (current === null) continue
          const lastValue = last.get(attr)
          if (!saved.has(attr) || (lastValue !== undefined && current !== lastValue)) saved.set(attr, current)
          const original = saved.get(attr) ?? current
          const translated = lang === 'en' ? original : translateText(original, lang)
          last.set(attr, translated)
          if (current !== translated) el.setAttribute(attr, translated)
        }
      })
    }

    const scheduleApply = () => {
      if (scheduled) return
      scheduled = true
      queueMicrotask(apply)
    }

    apply()
    const observer = new MutationObserver(scheduleApply)
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['placeholder', 'aria-label', 'aria-description', 'title', 'alt'],
    })
    window.addEventListener('lifeline-language-change', scheduleApply)
    return () => {
      observer.disconnect()
      window.removeEventListener('lifeline-language-change', scheduleApply)
    }
  }, [])

  return null
}
