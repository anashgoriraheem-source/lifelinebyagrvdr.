import { useEffect, useRef, useState } from 'react'
import { AlertTriangle, Ambulance, Check, Copy, MapPin, MessageSquare, Phone, Share2, Shield, Volume2, VolumeX } from 'lucide-react'
import { useApp } from '@/hooks/useApp'
import { appStore, cancelAlarm, dispatchAlarm, emergencyNumbers } from '@/lib/store'
import { startTracking, stopTracking } from '@/lib/location'
import { startSiren, stopSiren } from '@/lib/siren'
import { buildSosMessage, clockTime, getEmergencyProfile, mapsLink, smsHref, telHref } from '@/lib/sos'
import { requestBackgroundSms, type DispatchSmsStatus } from '@/lib/dispatch'

export function AlarmOverlay() {
  const alarm = useApp((s) => s.alarm)
  const countdown = useApp((s) => s.countdownSeconds)
  if (alarm.phase === 'idle') return null
  return alarm.phase === 'countdown' ? <Countdown total={countdown} /> : <Dispatched />
}

function Countdown({ total }: { total: number }) {
  const alarm = useApp((s) => s.alarm)
  const [left, setLeft] = useState(total)

  useEffect(() => {
    startSiren()
    startTracking()
    const started = alarm.startedAt ?? Date.now()
    const id = setInterval(() => {
      const l = Math.max(0, total - Math.floor((Date.now() - started) / 1000))
      setLeft(l)
      if (l === 0) dispatchAlarm()
    }, 200)
    return () => {
      // Keep the same SOS sound running as countdown transitions to the responder screen.
      // cancelAlarm() explicitly stops audio/vibration when the user confirms they are safe.
      clearInterval(id)
      // If the wearer cancelled, stop GPS. If countdown advanced to dispatch, keep the fix alive.
      if (appStore.state.alarm.phase === 'idle') stopTracking()
    }
  }, [alarm.startedAt, total])

  return (
    <div role="alertdialog" aria-live="assertive" className="fixed inset-0 z-40 flex flex-col items-center justify-between overflow-y-auto bg-rose-600 px-6 py-10 text-white">
      {alarm.demo && <DemoStrip />}
      <div className="mt-6 text-center">
        <AlertTriangle className="mx-auto size-12 animate-flash" strokeWidth={2.2} />
        <p className="mt-4 text-sm font-semibold uppercase tracking-[0.25em] text-rose-100">Emergency detected</p>
        <h2 className="mt-2 font-display text-4xl font-extrabold sm:text-5xl">{alarm.reason?.label}</h2>
        <p className="mt-2 font-mono text-lg text-rose-100">{alarm.reason?.reading}</p>
      </div>
      <div className="my-8 grid place-items-center">
        <div className="relative grid size-52 place-items-center rounded-full border-8 border-white/30">
          <span className="font-display text-8xl font-extrabold tabular">{left}</span>
        </div>
        <p className="mt-4 max-w-xs text-center text-rose-50">
          This countdown gives you time to cancel. When it ends, Aapda Setu attempts background SMS only if a secure server is configured, then shows the call sequence. Browser calls still need a tap.
        </p>
      </div>
      <div className="flex w-full max-w-sm flex-col gap-3">
        <HoldToCancel />
        <button onClick={dispatchAlarm} className="rounded-2xl border-2 border-white/60 py-4 text-lg font-bold transition hover:bg-white/10">
          Get help now
        </button>
      </div>
    </div>
  )
}

/** Cancelling needs a deliberate 1.5 s hold so a fall or a pocket press can't dismiss it. */
function HoldToCancel() {
  const [p, setP] = useState(0)
  const raf = useRef<number | null>(null)
  const begin = () => {
    const t0 = performance.now()
    const step = () => {
      const v = Math.min(1, (performance.now() - t0) / 1500)
      setP(v)
      if (v >= 1) return cancelAlarm('cancelled by wearer')
      raf.current = requestAnimationFrame(step)
    }
    raf.current = requestAnimationFrame(step)
  }
  const end = () => {
    if (raf.current) cancelAnimationFrame(raf.current)
    setP(0)
  }
  return (
    <button
      onPointerDown={begin}
      onPointerUp={end}
      onPointerLeave={end}
      onPointerCancel={end}
      className="relative h-20 select-none touch-none overflow-hidden rounded-2xl bg-white text-xl font-extrabold text-rose-700 shadow-2xl"
    >
      <span className="absolute inset-y-0 left-0 bg-emerald-400/40" style={{ width: `${p * 100}%` }} />
      <span className="relative">{p > 0 ? 'Keep holding…' : "I'm OK — hold to cancel"}</span>
    </button>
  )
}

function DemoStrip() {
  return (
    <div className="w-full max-w-xl rounded-xl bg-amber-300 px-4 py-2 text-center text-sm font-bold text-amber-950">
      DEMO MODE · no real alerts · nobody will be contacted
    </div>
  )
}

function Dispatched() {
  const alarm = useApp((s) => s.alarm)
  const loc = useApp((s) => s.location)
  const contacts = useApp((s) => s.contacts)
  const n = useApp(emergencyNumbers)
  const [siren, setSiren] = useState(true)
  const [smsStatus, setSmsStatus] = useState<DispatchSmsStatus>({ state: 'not-configured', detail: 'Background SMS is not connected yet.' })
  const [callStep, setCallStep] = useState(0)
  const latestFixRef = useRef(loc.fix)
  const smsIncidentRef = useRef<string | null>(null)
  latestFixRef.current = loc.fix
  const [copied, setCopied] = useState(false)
  const [, setProfileRevision] = useState(0)

  useEffect(() => {
    const refreshProfile = () => setProfileRevision((value) => value + 1)
    window.addEventListener('storage', refreshProfile)
    window.addEventListener('aapda-profile-updated', refreshProfile)
    return () => { window.removeEventListener('storage', refreshProfile); window.removeEventListener('aapda-profile-updated', refreshProfile) }
  }, [])

  useEffect(() => {
    startTracking()
    return () => {
      stopSiren()
      // The dispatched overlay unmounts when the alarm is resolved/cancelled.
      if (appStore.state.alarm.phase === 'idle') stopTracking()
    }
  }, [])
  useEffect(() => (siren ? startSiren() : stopSiren()), [siren])

  const msg = buildSosMessage(alarm.reason, loc.fix, { test: alarm.demo })
  const smsContacts = contacts.filter((c) => c.sms)
  const callContacts = contacts.filter((c) => c.call)

  // Background SMS only goes through a configured, authenticated server. No fake success state.
  useEffect(() => {
    let active = true
    if (alarm.demo) {
      setSmsStatus({ state: 'demo', detail: 'Demo mode: no SMS or real call is made.' })
      return () => { active = false }
    }
    if (!smsContacts.length) {
      setSmsStatus({ state: 'failed', detail: 'No contacts are enabled for SMS.' })
      return () => { active = false }
    }
    const incidentId = `aapda-${alarm.startedAt ?? Date.now()}`
    if (smsIncidentRef.current === incidentId) return () => { active = false }
    setSmsStatus({ state: 'sending', detail: 'Preparing alert and capturing the freshest available location…' })
    // Briefly allow the location watcher to deliver a fresh fix, but never wait indefinitely.
    const timer = window.setTimeout(() => {
      if (!active || smsIncidentRef.current === incidentId) return
      smsIncidentRef.current = incidentId
      const fix = latestFixRef.current
      requestBackgroundSms({
        incidentId,
        message: msg,
        contacts: smsContacts.map((c) => ({ name: c.name, phone: c.phone })),
        location: fix ? { lat: fix.lat, lng: fix.lng, accuracy: fix.accuracy, at: fix.at } : null,
        reason: alarm.reason?.label ?? 'SOS',
      }).then((status) => { if (active) setSmsStatus(status) })
    }, 900)
    return () => { active = false; window.clearTimeout(timer) }
    // Only dispatch once per incident; changing GPS must not send duplicate messages.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [alarm.startedAt, alarm.demo])

  const callQueue = [
    { label: 'Police', phone: n.police },
    { label: 'Ambulance', phone: n.ambulance },
    { label: callContacts[0]?.name || 'Emergency contact', phone: callContacts[0]?.phone || '' },
  ]
  const currentCall = callQueue[Math.min(callStep, callQueue.length - 1)]
  const callHref = !alarm.demo && currentCall?.phone ? telHref(currentCall.phone) : ''

  const share = async () => {
    try {
      if (navigator.share) await navigator.share({ title: 'Emergency — Aapda Setu', text: msg })
      else {
        await navigator.clipboard.writeText(msg)
        setCopied(true)
      }
    } catch {
      /* user dismissed */
    }
  }

  const resolve = () => {
    const patientName = getEmergencyProfile().name?.trim() || 'The patient'
    const okMsg = `${patientName} is safe now — the Aapda Setu alert at ${clockTime(alarm.startedAt ?? Date.now())} is resolved. Thank you.`
    if (!alarm.demo && Object.keys(done).length && smsContacts.length && confirm('Send an "I\'m OK" message to your contacts?')) {
      window.location.href = smsHref(smsContacts.map((c) => c.phone), okMsg)
    }
    cancelAlarm('marked resolved')
  }

  return (
    <div role="alertdialog" className="fixed inset-0 z-40 overflow-y-auto bg-slate-950 text-white">
      <div className="bg-rose-600 px-5 pb-6 pt-8">
        <div className="mx-auto max-w-2xl">
          {alarm.demo && <DemoStrip />}
          <p className="mt-3 text-xs font-semibold uppercase tracking-[0.25em] text-rose-100">
            {alarm.reason?.label} · {clockTime(alarm.startedAt ?? Date.now())}
          </p>
          <h2 className="mt-1 font-display text-3xl font-extrabold sm:text-4xl">
            {alarm.demo ? 'Demo alert — this is what happens next' : 'Get help now'}
          </h2>
          <p className="mt-1 text-rose-50">
            {alarm.demo ? 'Demo only: no real calls or messages will be started.' : 'Background SMS is attempted only through a configured secure server. Browser calling still needs you to tap each call and return to continue; this page cannot reliably detect call end.'}
          </p>
          {!alarm.demo && <p className="mt-2 rounded-xl bg-rose-950/30 p-3 text-xs leading-relaxed text-rose-50">Emergency numbers in this prototype may not be verified for your current area. Confirm the displayed number before calling; if it is wrong, use your phone’s emergency-call feature or local official guidance.</p>}
          <a
            href={alarm.demo || !n.general ? undefined : telHref(n.general)}
            onClick={() => { /* Opening the dialler does not confirm a call. */ }}
            aria-disabled={alarm.demo || !n.general}
            className={`mt-5 flex items-center justify-center gap-3 rounded-2xl bg-white py-5 text-2xl font-extrabold text-rose-700 shadow-2xl ${alarm.demo || !n.general ? 'pointer-events-none opacity-60' : 'active:scale-[0.98]'}`}
          >
            <Phone className="size-7" strokeWidth={2.6} /> {n.general ? `Call emergency ${n.general}` : 'Emergency number not verified'}
          </a>
        </div>
      </div>

      <div className="mx-auto grid max-w-2xl gap-4 px-5 py-6">
        {/* Location */}
        <section className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <MapPin className="size-4 text-rose-400" /> Live location
            <span className="ml-auto text-xs font-medium text-slate-400">
              {loc.status === 'tracking' && loc.fix ? `±${Math.round(loc.fix.accuracy)} m · ${clockTime(loc.fix.at)}` : loc.status === 'denied' ? 'Permission denied' : 'Locating…'}
            </span>
          </div>
          {loc.fix ? (
            <a href={mapsLink(loc.fix)} target="_blank" rel="noreferrer" className="mt-2 block font-mono text-sm text-sky-300 underline-offset-4 hover:underline">
              {loc.fix.lat.toFixed(5)}, {loc.fix.lng.toFixed(5)} — open map
            </a>
          ) : (
            <p className="mt-2 text-sm text-slate-400">
              {loc.status === 'denied' ? 'Enable location for this site so responders can find you. Say your address when you call.' : 'Getting a GPS fix. Messages sent now will say location is unavailable.'}
            </p>
          )}
        </section>

        {/* Dispatch status */}
        <section className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="flex items-center gap-2">
            <MessageSquare className="size-5 text-amber-300" />
            <h3 className="font-semibold">Background SMS status</h3>
            <span className={`ml-auto rounded-full px-2.5 py-1 text-xs font-bold ${smsStatus.state === 'accepted' ? 'bg-emerald-500/20 text-emerald-300' : smsStatus.state === 'sending' ? 'bg-amber-500/20 text-amber-200' : 'bg-white/10 text-slate-300'}`}>{smsStatus.stateLabel ?? smsStatus.state.replace('-', ' ')}</span>
          </div>
          <p className="mt-2 text-sm text-slate-300">{smsStatus.detail}</p>
          {smsStatus.state === 'accepted' && <p className="mt-1 text-xs text-amber-200">Accepted by the SMS service does not guarantee delivery. Check provider delivery receipts.</p>}
        </section>

        {/* Safe web calling queue: each call is a user-initiated tel: action. */}
        <section className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10">
          <h3 className="font-semibold">Call sequence</h3>
          <p className="mt-1 text-sm text-slate-400">{alarm.demo ? 'Demo only: steps can be previewed without calling anyone.' : 'Tap the current call, speak to the operator, return here, then continue to the next call. A website cannot automatically dial or reliably detect hang-up.'}</p>
          <ol className="mt-3 space-y-2">
            {callQueue.map((item, index) => <li key={`${index}-${item.label}`} className={`flex items-center gap-3 rounded-xl p-3 ${index === callStep ? 'bg-rose-500/15 ring-1 ring-rose-400/40' : index < callStep ? 'bg-emerald-500/10' : 'bg-white/5'}`}>
              <span className="grid size-7 place-items-center rounded-full bg-white/10 text-xs font-bold">{index + 1}</span>
              <span className="min-w-0 flex-1"><span className="block font-semibold">{item.label}</span><span className="block text-xs text-slate-400">{item.phone || 'No number configured'}</span></span>
              {index < callStep && <Check className="size-4 text-emerald-400" />}
            </li>)}
          </ol>
          {alarm.demo ? (
            <button onClick={() => setCallStep((step) => Math.min(step + 1, callQueue.length - 1))} className="mt-3 w-full rounded-xl border border-amber-300/30 py-3 font-bold text-amber-200">Preview next step (no real call)</button>
          ) : (
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <a href={callHref || undefined} onClick={() => { /* Opening the dialler does not confirm a call. */ }} aria-disabled={!callHref} className={`flex items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-3 font-bold text-white ${callHref ? '' : 'pointer-events-none opacity-40'}`}><Phone className="size-4" />Call {currentCall?.label || 'next'}</a>
              <button onClick={() => setCallStep((step) => Math.min(step + 1, callQueue.length - 1))} disabled={callStep >= callQueue.length - 1} className="rounded-xl border border-white/15 px-4 py-3 font-bold disabled:opacity-40">Call ended — continue</button>
            </div>
          )}
          {callStep >= callQueue.length - 1 && <p className="mt-2 text-xs text-emerald-300">Last call in the configured sequence. If the person is still in danger, stay on the line with emergency services.</p>}
        </section>

        {/* Emergency services */}
        <section className="grid grid-cols-2 gap-3">
          <ServiceButton icon={<Shield className="size-5" />} label="Police" number={n.police} demo={alarm.demo} />
          <ServiceButton icon={<Ambulance className="size-5" />} label="Ambulance" number={n.ambulance} demo={alarm.demo} />
          <a
            href={alarm.demo || !n.smsNumber ? undefined : smsHref([n.smsNumber], msg)}
            onClick={(event) => { if (!alarm.demo && n.smsNumber) { event.preventDefault(); window.location.href = smsHref([n.smsNumber], buildSosMessage(alarm.reason, loc.fix, { test: alarm.demo })) } }}
            aria-disabled={alarm.demo || !n.smsNumber}
            className={`col-span-2 flex items-center gap-3 rounded-2xl bg-rose-500/15 p-4 ring-1 ring-rose-400/30 ${alarm.demo || !n.smsNumber ? 'pointer-events-none opacity-50' : 'hover:bg-rose-500/25'}`}
          >
            <MessageSquare className="size-5 text-rose-300" />
            <span className="flex-1">
              <span className="block font-semibold">{n.smsNumber ? `Text police & ambulance (${n.smsNumber})` : 'Emergency SMS number not verified'}</span>
              <span className="block text-xs text-slate-400">Opens your messaging app; you must review the number and tap Send. Delivery is not confirmed here.</span>
            </span>
            <span className="text-xs text-slate-400">Opens SMS app</span>
          </a>
        </section>
        <p className="-mt-2 text-xs leading-relaxed text-slate-400">Selecting a call option only opens the phone dialler. It does not prove that the call connected. Confirm the number and speak to the operator.</p>

        {/* Contacts */}
        <section className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Your emergency contacts</h3>
            {smsContacts.length > 0 && (
              <a
                href={alarm.demo ? undefined : smsHref(smsContacts.map((c) => c.phone), msg)}
                onClick={(event) => { if (!alarm.demo) { event.preventDefault(); window.location.href = smsHref(smsContacts.map((c) => c.phone), buildSosMessage(alarm.reason, loc.fix, { test: alarm.demo })) } }}
                className={`rounded-full bg-white px-3 py-1.5 text-sm font-bold text-slate-900 ${alarm.demo ? 'pointer-events-none opacity-50' : ''}`}
              >
                Message all · opens SMS app
              </a>
            )}
          </div>
          <ul className="mt-3 divide-y divide-white/10">
            {contacts.map((c) => (
              <li key={c.id} className="flex items-center gap-3 py-2.5">
                <span className="grid size-9 place-items-center rounded-full bg-white/10 text-sm font-bold">{c.name[0]}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-medium">{c.name}</span>
                  <span className="block text-xs text-slate-400">{c.relationship} · {c.phone}</span>
                </span>
                {c.sms && (
                  <a aria-label={`Text ${c.name}`} href={alarm.demo ? undefined : smsHref([c.phone], msg)} onClick={(event) => { if (!alarm.demo) { event.preventDefault(); window.location.href = smsHref([c.phone], buildSosMessage(alarm.reason, loc.fix, { test: alarm.demo })) } }} className={`grid size-10 place-items-center rounded-full bg-white/10 ${alarm.demo ? 'pointer-events-none opacity-50' : ''}`}>
                    <MessageSquare className="size-4" />
                  </a>
                )}
                {c.call && (
                  <a aria-label={`Call ${c.name}`} href={alarm.demo ? undefined : telHref(c.phone)} onClick={() => { /* Opening the dialler does not confirm a call. */ }} className={`grid size-10 place-items-center rounded-full bg-white/10 ${alarm.demo ? 'pointer-events-none opacity-50' : ''}`}>
                    <Phone className="size-4" />
                  </a>
                )}
              </li>
            ))}
          </ul>
        </section>

        {/* Message preview */}
        <section className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="flex items-center gap-2">
            <h3 className="mr-auto font-semibold">Emergency message preview</h3>
            <button onClick={share} className="flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-sm hover:bg-white/20">
              {copied ? <Copy className="size-4" /> : <Share2 className="size-4" />} {copied ? 'Copied' : 'Share'}
            </button>
          </div>
          <pre className="mt-3 whitespace-pre-wrap break-words font-mono text-xs leading-relaxed text-slate-300">{msg}</pre>
        </section>

        <div className="flex flex-wrap gap-3 pb-[48dvh] sm:pb-28">
          <button onClick={() => setSiren((v) => !v)} className="flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-3 font-semibold hover:bg-white/20">
            {siren ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />} {siren ? 'Stop siren' : 'Sound siren'}
          </button>
          <button onClick={resolve} className="flex-1 rounded-2xl bg-emerald-500 px-4 py-3 font-bold text-emerald-950 hover:bg-emerald-400">
            I'm safe — mark resolved
          </button>
        </div>
      </div>
    </div>
  )
}

function ServiceButton(props: { icon: React.ReactNode; label: string; number: string; demo: boolean }) {
  return (
    <a
      href={props.demo || !props.number ? undefined : telHref(props.number)}
      aria-disabled={props.demo || !props.number}
      className={`flex items-center gap-3 rounded-2xl bg-white/5 p-4 ring-1 ring-white/10 ${props.demo || !props.number ? 'pointer-events-none opacity-50' : 'hover:bg-white/10'}`}
    >
      <span className="grid size-10 place-items-center rounded-xl bg-white/10">{props.icon}</span>
      <span className="flex-1">
        <span className="block text-sm text-slate-400">{props.label}</span>
        <span className="block font-mono text-xl font-bold">{props.number || 'Not verified'}</span>
      </span>
    </a>
  )
}

