import { createFileRoute, Link } from '@tanstack/react-router'
import { useEffect, useRef, useState } from 'react'
import { AlarmClock, CheckCircle2, MapPin, Shield, TimerReset, BellRing } from 'lucide-react'

export const Route = createFileRoute('/journey')({
  ssr: false,
  head: () => ({ meta: [{ title: 'Safe journey · Aapda Setu' }] }),
  component: Journey,
})

type SavedJourney = { destination: string; minutes: number; startedAt: number; dueAt: number; checkedIn?: boolean }
const STORAGE_KEY = 'aapda-setu-journey'
function readJourney(): SavedJourney | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const value = JSON.parse(raw) as Partial<SavedJourney>
    if (typeof value.destination !== 'string' || typeof value.dueAt !== 'number' || typeof value.startedAt !== 'number') return null
    if (!Number.isFinite(value.dueAt) || !Number.isFinite(value.startedAt)) return null
    return { destination: value.destination.slice(0, 160), minutes: Number(value.minutes) || 30, startedAt: value.startedAt, dueAt: value.dueAt, checkedIn: Boolean(value.checkedIn) }
  } catch { return null }
}
function persistJourney(value: SavedJourney | null) {
  try { if (value) localStorage.setItem(STORAGE_KEY, JSON.stringify(value)); else localStorage.removeItem(STORAGE_KEY) } catch { /* storage may be disabled */ }
}

function Journey() {
  const [destination, setDestination] = useState('')
  const [minutes, setMinutes] = useState(30)
  const [journey, setJourney] = useState<SavedJourney | null>(null)
  const [now, setNow] = useState(Date.now())
  const [done, setDone] = useState(false)
  const notified = useRef(false)

  useEffect(() => {
    const saved = readJourney()
    if (saved && !saved.checkedIn) {
      setJourney(saved)
      setDestination(saved.destination)
      setMinutes(saved.minutes)
    } else if (saved?.checkedIn) {
      persistJourney(null)
      setDone(true)
    }
  }, [])
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000)
    const onVisible = () => setNow(Date.now())
    document.addEventListener('visibilitychange', onVisible)
    return () => { window.clearInterval(id); document.removeEventListener('visibilitychange', onVisible) }
  }, [])

  const remain = journey ? Math.max(0, Math.ceil((journey.dueAt - now) / 1000)) : 0
  useEffect(() => {
    if (!journey || remain > 0 || notified.current) return
    notified.current = true
    if ('Notification' in window && Notification.permission === 'granted') {
      try { new Notification('Aapda Setu journey check-in', { body: 'Your expected check-in time has passed. If you are safe, check in now.' }) } catch { /* notification unavailable */ }
    }
  }, [journey, remain])

  const start = async () => {
    if ('Notification' in window && Notification.permission === 'default') {
      try { await Notification.requestPermission() } catch { /* optional browser permission */ }
    }
    const startedAt = Date.now()
    const next: SavedJourney = { destination: destination.trim().slice(0, 160), minutes, startedAt, dueAt: startedAt + minutes * 60_000 }
    notified.current = false
    setJourney(next)
    setDone(false)
    persistJourney(next)
  }
  const checkIn = () => { persistJourney(null); setJourney(null); setDone(true); notified.current = false }
  const end = () => { persistJourney(null); setJourney(null); setDone(false); notified.current = false }

  return <main className="mx-auto max-w-5xl px-4 pb-28 pt-8">
    <div className="rounded-[2rem] bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-800 p-8 text-white sm:p-10">
      <p className="text-xs font-bold uppercase tracking-[.25em] text-indigo-300">Personal safety</p>
      <h1 className="mt-3 font-display text-4xl font-extrabold sm:text-5xl">Your journey. Your check-in.</h1>
      <p className="mt-3 max-w-2xl text-slate-300">Set an expected arrival and check in when you reach safely. The timer is saved on this device and restored when you reopen this page. It cannot reliably run in the background or automatically alert contacts.</p>
    </div>
    <div className="mt-6 grid gap-5 md:grid-cols-5">
      <section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:col-span-3">
        <h2 className="font-display text-2xl font-bold">Plan a safe journey</h2>
        {!journey ? <>
          <label className="mt-5 block text-sm font-semibold">Destination or journey note<input value={destination} maxLength={160} onChange={e => setDestination(e.target.value)} placeholder="e.g. Coaching class → home" className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-indigo-400" /></label>
          <label className="mt-5 block text-sm font-semibold">Expected travel time<select value={minutes} onChange={e => setMinutes(Number(e.target.value))} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3">{[15, 30, 45, 60, 90, 120, 180].map(n => <option key={n} value={n}>{n} minutes</option>)}</select></label>
          <button onClick={() => void start()} className="mt-5 w-full rounded-full bg-indigo-700 px-5 py-3 font-bold text-white">Start check-in timer</button>
          <p className="mt-3 text-xs leading-relaxed text-slate-500">If permitted, your browser may show a reminder while this app is open. Browser notifications are not a guaranteed safety alert.</p>
        </> : <div className="mt-5 rounded-2xl bg-indigo-50 p-5">
          <p className="text-sm font-bold text-indigo-800">{journey.destination || 'Journey in progress'}</p>
          <p className="mt-1 text-xs text-indigo-700">Started {new Date(journey.startedAt).toLocaleString()} · Expected by {new Date(journey.dueAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
          <p className="mt-3 font-mono text-4xl font-extrabold text-indigo-950">{Math.floor(remain / 60).toString().padStart(2, '0')}:{(remain % 60).toString().padStart(2, '0')}</p>
          {remain === 0 && <p role="status" className="mt-2 text-sm font-semibold text-amber-800">Expected check-in time passed. This is only a reminder, not proof that you are in danger. Check in or contact someone you trust.</p>}
          <div className="mt-4 flex flex-wrap gap-2"><button onClick={checkIn} className="rounded-full bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white">I'm safe — check in</button><button onClick={end} className="rounded-full border border-slate-200 px-4 py-2.5 text-sm font-bold">End timer</button></div>
        </div>}
        {done && <p className="mt-4 flex items-center gap-2 text-sm font-bold text-emerald-700"><CheckCircle2 size={18} /> Check-in completed. Glad you made it!</p>}
      </section>
      <aside className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:col-span-2"><Shield className="text-indigo-600" size={28} /><h2 className="mt-3 font-display text-xl font-bold">Make it safer</h2><ul className="mt-4 space-y-3 text-sm leading-relaxed text-slate-600"><li className="flex gap-2"><MapPin size={17} className="mt-0.5 shrink-0 text-indigo-600" /> Share your route and expected arrival with a trusted person before leaving.</li><li className="flex gap-2"><AlarmClock size={17} className="mt-0.5 shrink-0 text-indigo-600" /> Keep your phone charged and use an easy-to-reach emergency shortcut.</li><li className="flex gap-2"><TimerReset size={17} className="mt-0.5 shrink-0 text-indigo-600" /> If plans change, update your check-in rather than relying on a timer alone.</li><li className="flex gap-2"><BellRing size={17} className="mt-0.5 shrink-0 text-indigo-600" /> An overdue timer never automatically contacts anyone in this prototype.</li></ul><Link to="/contacts" className="mt-5 inline-flex rounded-full bg-slate-900 px-4 py-2.5 text-sm font-bold text-white">Review contacts</Link></aside>
    </div>
  </main>
}
