import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { Activity, ArrowRight, HeartPulse, ShieldCheck, UserRound } from 'lucide-react'

export const Route = createFileRoute('/profile')({
  ssr: false,
  head: () => ({ meta: [{ title: 'Emergency profile · Aapda Setu' }] }),
  component: EmergencyProfile,
})

const inputClass = 'mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-rose-400 focus:ring-4 focus:ring-rose-100'
const labelClass = 'block text-sm font-semibold text-slate-700'

function EmergencyProfile() {
  const navigate = useNavigate()
  const saved = (() => { try { return JSON.parse(localStorage.getItem('aapda-setu-emergency-profile') || '{}') } catch { return {} } })()
  const [name, setName] = useState(saved.name || '')
  const [age, setAge] = useState(saved.age || '')
  const [gender, setGender] = useState(saved.gender || '')
  const [bloodType, setBloodType] = useState(saved.bloodType || '')
  const [allergies, setAllergies] = useState(saved.allergies || '')
  const [conditions, setConditions] = useState(saved.conditions || '')
  const [medications, setMedications] = useState(saved.medications || '')
  const [error, setError] = useState('')

  const saveAndContinue = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!name.trim() || !age || !gender || !bloodType || !allergies.trim() || !conditions.trim() || !medications.trim()) { setError('Complete every profile field. If a medical field does not apply, enter “None”; if unknown, enter “Not sure”.'); return }
    try {
      localStorage.setItem('aapda-setu-emergency-profile', JSON.stringify({ name: name.trim(), age, gender, bloodType: bloodType.trim() || 'Unknown', allergies: allergies.trim() || 'Not provided', conditions: conditions.trim() || 'Not provided', medications: medications.trim() || 'Not provided', completed: true, updatedAt: new Date().toISOString() }))
    } catch { setError('This browser cannot save your profile. Check storage settings or use another browser; do not assume your emergency details were saved.'); return }
    window.dispatchEvent(new Event('aapda-profile-updated'))
    void navigate({ to: '/contacts' })
  }

  return <main className="relative min-h-[calc(100vh-64px)] overflow-hidden bg-slate-50 px-4 py-8 sm:py-12">
    <div className="pointer-events-none absolute -right-24 -top-24 size-80 rounded-full bg-rose-100/70 blur-3xl" />
    <div className="pointer-events-none absolute -bottom-24 -left-20 size-80 rounded-full bg-orange-100/70 blur-3xl" />
    <div className="relative mx-auto max-w-3xl">
      <div className="mb-6 flex items-center gap-3"><img src="/aapda-setu-logo.png" alt="Aapda Setu" className="size-12 rounded-xl object-cover"/><div><p className="font-display text-lg font-extrabold text-slate-900">Aapda Setu</p><p className="text-sm text-slate-500">Your safety profile</p></div></div>
      <div className="overflow-hidden rounded-3xl bg-white shadow-xl shadow-slate-900/5 ring-1 ring-slate-200/80">
        <div className="bg-slate-950 px-6 py-7 text-white sm:px-9 sm:py-9"><div className="mb-4 grid size-12 place-items-center rounded-2xl bg-white/10"><ShieldCheck className="size-6 text-rose-300"/></div><p className="text-xs font-bold uppercase tracking-[0.18em] text-rose-300">Step 1 of 2 · Emergency readiness</p><h1 className="mt-2 font-display text-3xl font-extrabold sm:text-4xl">Let’s get to know you</h1><p className="mt-3 max-w-xl leading-6 text-slate-300">A few details can help trusted responders understand your needs in an emergency. Fill in what you know; you can update this information later.</p></div>
        <form onSubmit={saveAndContinue} className="space-y-7 p-6 sm:p-9">
          <section><h2 className="flex items-center gap-2 font-display text-xl font-bold text-slate-900"><UserRound className="size-5 text-rose-600"/> Personal details</h2><div className="mt-4 grid gap-4 sm:grid-cols-2"><label className={labelClass}>Full name *<input className={inputClass} value={name} onChange={e=>setName(e.target.value)} autoComplete="name" placeholder="Your full name" required/></label><label className={labelClass}>Age *<input className={inputClass} type="number" min="1" max="120" value={age} onChange={e=>setAge(e.target.value)} placeholder="Your age" required/></label><label className={labelClass}>Gender *<select className={inputClass} value={gender} onChange={e=>setGender(e.target.value)} required><option value="">Select an option</option><option>Female</option><option>Male</option><option>Non-binary</option><option>Prefer not to say</option><option>Self-describe</option></select></label><label className={labelClass}>Blood type *<select className={inputClass} value={bloodType} onChange={e=>setBloodType(e.target.value)} required><option value="">Select or leave unknown</option>{['A+','A−','B+','B−','AB+','AB−','O+','O−','Unknown'].map(v=><option key={v}>{v}</option>)}</select></label></div></section>
          <section><h2 className="flex items-center gap-2 font-display text-xl font-bold text-slate-900"><HeartPulse className="size-5 text-rose-600"/> Medical information</h2><p className="mt-2 text-sm leading-6 text-slate-500">Complete each field. Enter “None” if not applicable or “Not sure” if you don’t know.</p><div className="mt-4 grid gap-4"><label className={labelClass}>Allergies *<textarea className={inputClass} rows={2} value={allergies} onChange={e=>setAllergies(e.target.value)} required placeholder="e.g. peanuts, penicillin, none, or not sure"/></label><label className={labelClass}>Medical conditions *<textarea className={inputClass} rows={2} value={conditions} onChange={e=>setConditions(e.target.value)} required placeholder="e.g. asthma, diabetes, none, or not sure"/></label><label className={labelClass}>Current medications *<textarea className={inputClass} rows={2} value={medications} onChange={e=>setMedications(e.target.value)} required placeholder="Medication names, none, or not sure"/></label></div></section>
          <div className="rounded-2xl border border-rose-100 bg-rose-50/70 p-4"><div className="flex gap-3"><Activity className="mt-0.5 size-5 shrink-0 text-rose-600"/><div><h3 className="font-bold text-slate-900">Next: add an emergency contact</h3><p className="mt-1 text-sm leading-6 text-slate-600">After saving your profile, we’ll take you to the emergency contacts page. You’ll need to add at least one trusted contact before continuing to the main interface.</p></div></div></div>
          {error && <p role="alert" className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-semibold text-rose-700">{error}</p>}
          <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-2xl bg-rose-600 px-5 py-4 font-bold text-white shadow-lg shadow-rose-600/20 transition hover:bg-rose-700 focus:outline-none focus:ring-4 focus:ring-rose-200">Save and continue to emergency contacts <ArrowRight className="size-5"/></button>
          <p className="text-center text-xs leading-5 text-slate-400">Your details are saved in this browser for this prototype. Secure account-linked storage must be configured before production use.</p>
        </form>
      </div>
    </div>
  </main>
}
