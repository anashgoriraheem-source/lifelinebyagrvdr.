import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'
import { useEffect } from 'react'

import '../styles.css'
import { Nav } from '@/components/Nav'
import { AlarmOverlay } from '@/components/AlarmOverlay'
import { Assistant } from '@/components/Assistant'
import { VitalsEngine } from '@/components/VitalsEngine'
import { TranslationRuntime } from '@/components/TranslationRuntime'
import { OfflineStatus } from '@/components/OfflineStatus'

const siteName = 'Aapda Setu — emergency support'
const siteDescription =
  'Aapda Setu is an emergency-support prototype with contact handoff, local first-aid guidance, simulated vital readings and preparedness tools. It does not provide guaranteed emergency dispatch.'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1, viewport-fit=cover' },
      { name: 'theme-color', content: '#080a0f' },
      { title: siteName },
      { name: 'description', content: siteDescription },
      { property: 'og:title', content: siteName },
      { property: 'og:description', content: siteDescription },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
    links: [
      { rel: 'icon', href: '/favicon.svg', type: 'image/svg+xml' },
      { rel: 'manifest', href: '/manifest.webmanifest' },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    if ('serviceWorker' in navigator && window.isSecureContext) {
      navigator.serviceWorker.register('/sw.js').catch(() => { /* offline support is optional if registration is blocked */ })
    }
  }, [])
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body className="grain min-h-screen">
        <TranslationRuntime />
        <VitalsEngine />
        <Nav />
        <OfflineStatus />
        {children}
        <Assistant />
        <AlarmOverlay />
        <Scripts />
      </body>
    </html>
  )
}
