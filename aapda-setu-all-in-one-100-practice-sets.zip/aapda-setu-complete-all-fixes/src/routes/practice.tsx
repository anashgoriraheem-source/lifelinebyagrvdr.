import { createFileRoute, Link } from '@tanstack/react-router'
import { useEffect, useMemo, useState } from 'react'
import { translateText, type LanguageCode } from '@/lib/i18n'
import { CheckCircle2, ClipboardCheck, HeartPulse, MapPin, Siren, XCircle, RotateCcw, Trophy } from 'lucide-react'
export const Route = createFileRoute('/practice')({ssr:false,head:()=>({meta:[{title:'Practice · Aapda Setu'}]}),component:Practice})
const cases = [
  {
    "category": "First aid",
    "title": "Feeling faint in a public place",
    "desc": "You feel dizzy and unsteady while waiting at a bus stand.",
    "question": "What should you do first?",
    "options": [
      "Move somewhere safe, sit or lie down, and ask a nearby person for help",
      "Keep walking quickly to reach home",
      "Ignore it and continue alone"
    ],
    "correct": 0,
    "why": "This lowers the chance of a fall. Ask someone nearby to stay with you and seek urgent help if symptoms are severe or do not improve."
  },
  {
    "category": "First aid",
    "title": "A person is unresponsive",
    "desc": "A person collapses and does not respond when spoken to.",
    "question": "What is the safest next step?",
    "options": [
      "Give them food or water immediately",
      "Get emergency help, check for normal breathing, and follow dispatcher instructions",
      "Leave them alone to recover"
    ],
    "correct": 1,
    "why": "An unresponsive person should not be given anything by mouth. Contact emergency services and follow the dispatcher’s instructions."
  },
  {
    "category": "Floods",
    "title": "Floodwater on your route",
    "desc": "Moving water is crossing a road you planned to use.",
    "question": "What should you do?",
    "options": [
      "Walk or drive through if it looks shallow",
      "Turn back and follow official evacuation advice",
      "Stand near the water to estimate its depth"
    ],
    "correct": 1,
    "why": "Floodwater can be deeper and faster than it appears. Never enter it."
  },
  {
    "category": "Fire safety",
    "title": "Smoke in a building",
    "desc": "You notice smoke in a building and the alarm sounds.",
    "question": "What should you do?",
    "options": [
      "Use the nearest safe exit and stay low if there is smoke",
      "Hide in a lift",
      "Collect your belongings first"
    ],
    "correct": 0,
    "why": "Leave promptly by a safe exit. Do not use lifts during a fire; call emergency services from a safe place."
  },
  {
    "category": "Fire safety",
    "title": "A blocked exit",
    "desc": "Your usual exit is blocked by smoke.",
    "question": "What is the safer choice?",
    "options": [
      "Push through the smoke",
      "Use another safe exit; if trapped, close doors and signal for help",
      "Open every window and keep searching"
    ],
    "correct": 1,
    "why": "Avoid smoke and seek another safe route. If trapped, close doors between you and smoke and contact emergency services."
  },
  {
    "category": "Earthquakes",
    "title": "Shaking starts indoors",
    "desc": "You are inside a classroom when an earthquake begins.",
    "question": "What should you do?",
    "options": [
      "Run to the stairs immediately",
      "Drop, cover, and hold on away from windows",
      "Stand beside a glass window"
    ],
    "correct": 1,
    "why": "Drop, cover your head and neck under sturdy furniture if possible, and hold on until shaking stops."
  },
  {
    "category": "Earthquakes",
    "title": "Shaking stops",
    "desc": "The earthquake has stopped and you are indoors.",
    "question": "What should you do next?",
    "options": [
      "Check for hazards and leave carefully if the building is damaged",
      "Use the lift to go downstairs",
      "Light a match to check for gas"
    ],
    "correct": 0,
    "why": "Watch for damaged structures, broken glass, and possible gas leaks. Use stairs, not lifts, if evacuation is needed."
  },
  {
    "category": "Road safety",
    "title": "Approaching an accident",
    "desc": "You witness a road collision.",
    "question": "What is a safe first action?",
    "options": [
      "Run into traffic to help immediately",
      "Keep yourself safe, alert emergency services, and follow their instructions",
      "Move injured people without checking for danger"
    ],
    "correct": 1,
    "why": "Protect yourself from traffic and other hazards first. Call emergency services and follow dispatcher guidance."
  },
  {
    "category": "Road safety",
    "title": "A seat belt",
    "desc": "You are travelling in a car for a short trip.",
    "question": "What should you do?",
    "options": [
      "Wear your seat belt even for a short journey",
      "Wear it only on highways",
      "Sit behind the driver without a belt"
    ],
    "correct": 0,
    "why": "Seat belts reduce the risk of serious injury on every trip, including short journeys."
  },
  {
    "category": "Weather",
    "title": "Lightning nearby",
    "desc": "You hear thunder while playing in an open field.",
    "question": "Where should you go?",
    "options": [
      "Under the tallest isolated tree",
      "Inside a substantial enclosed building or hard-topped vehicle",
      "Stay in the open and lie flat"
    ],
    "correct": 1,
    "why": "Move to a substantial building or enclosed hard-topped vehicle. Avoid open areas and isolated trees."
  },
  {
    "category": "Weather",
    "title": "Extreme heat",
    "desc": "It is very hot and you feel weak during outdoor activity.",
    "question": "What is a sensible response?",
    "options": [
      "Move to a cooler place, rest, and sip water if alert",
      "Continue exercising to finish faster",
      "Wear extra layers"
    ],
    "correct": 0,
    "why": "Stop activity, cool down, and drink water if you are fully alert. Seek urgent help for confusion, fainting, or severe symptoms."
  },
  {
    "category": "Preparedness",
    "title": "Emergency contacts",
    "desc": "You are preparing an emergency plan with your family.",
    "question": "What should it include?",
    "options": [
      "Only one person’s phone number",
      "Meeting point, key contacts, and an out-of-area contact",
      "A secret route no one else knows"
    ],
    "correct": 1,
    "why": "A shared plan with contacts and a meeting point helps everyone know what to do."
  },
  {
    "category": "Preparedness",
    "title": "Emergency kit",
    "desc": "Which is useful in a basic emergency kit?",
    "question": "What belongs in the kit?",
    "options": [
      "Water, a torch, batteries, a first-aid kit, and essential medicines",
      "Only toys and decorations",
      "Perishable food with no water"
    ],
    "correct": 0,
    "why": "Keep basic supplies such as water, a torch, batteries, first-aid supplies, and essential medicines."
  },
  {
    "category": "Preparedness",
    "title": "Official warnings",
    "desc": "You receive an evacuation warning from local authorities.",
    "question": "What should you do?",
    "options": [
      "Ignore it until you see danger",
      "Follow official instructions and leave by the advised route",
      "Forward an unverified rumour instead"
    ],
    "correct": 1,
    "why": "Official alerts are designed to reduce risk. Follow the instructions and use the recommended route."
  },
  {
    "category": "First aid",
    "title": "Burn from hot liquid",
    "desc": "Someone gets a minor hot-liquid burn.",
    "question": "What is an appropriate first-aid step?",
    "options": [
      "Cool the burn under cool running water and seek medical advice as needed",
      "Apply butter or toothpaste",
      "Put ice directly on the burn"
    ],
    "correct": 0,
    "why": "Cool the area with cool running water. Do not apply butter, toothpaste, or ice directly. Get medical help for serious burns."
  },
  {
    "category": "First aid",
    "title": "Possible broken bone",
    "desc": "A person may have a broken arm after a fall.",
    "question": "What should you do?",
    "options": [
      "Try to straighten the arm",
      "Keep it still, support it comfortably, and get medical help",
      "Ask them to test it by lifting something heavy"
    ],
    "correct": 1,
    "why": "Avoid moving or straightening a suspected fracture. Support it in the position found and seek medical care."
  },
  {
    "category": "First aid",
    "title": "Severe bleeding",
    "desc": "Someone has a serious external bleed.",
    "question": "What should you do while help is coming?",
    "options": [
      "Apply firm direct pressure with a clean cloth or dressing",
      "Wash the wound for several minutes first",
      "Ask them to walk around"
    ],
    "correct": 0,
    "why": "Firm direct pressure can help control bleeding. Call emergency services for severe bleeding and follow dispatcher advice."
  },
  {
    "category": "First aid",
    "title": "Choking concern",
    "desc": "A person cannot speak, breathe, or cough effectively.",
    "question": "What is the best response?",
    "options": [
      "Give them a drink",
      "Call emergency services and follow recognised first-aid guidance for their age",
      "Leave them alone"
    ],
    "correct": 1,
    "why": "Severe choking is an emergency. Get help and follow dispatcher instructions or recognised training for the person’s age."
  },
  {
    "category": "Floods",
    "title": "Flood evacuation",
    "desc": "Authorities tell your neighbourhood to evacuate due to flooding.",
    "question": "What should you do?",
    "options": [
      "Wait beside the river to watch the water",
      "Leave promptly using the official safe route",
      "Take a shortcut through a flooded underpass"
    ],
    "correct": 1,
    "why": "Leave when instructed and avoid flooded roads, underpasses, and waterways."
  },
  {
    "category": "Floods",
    "title": "After floodwater recedes",
    "desc": "A street looks dry after a flood.",
    "question": "What is the safest assumption?",
    "options": [
      "It is automatically safe to walk there barefoot",
      "There may still be contamination or hidden hazards; follow local safety advice",
      "All electrical hazards are gone"
    ],
    "correct": 1,
    "why": "Floodwater can leave contamination, debris, and electrical hazards. Follow local authority guidance."
  },
  {
    "category": "Fire safety",
    "title": "Clothes catch fire",
    "desc": "A person’s clothing catches fire.",
    "question": "What should you encourage them to do?",
    "options": [
      "Stop, drop, and roll; protect the face",
      "Run as fast as possible",
      "Hide behind a curtain"
    ],
    "correct": 0,
    "why": "Stop, drop, and roll can help smother flames. Call for emergency help and get medical care for burns."
  },
  {
    "category": "Fire safety",
    "title": "Electrical fire",
    "desc": "You see a fire involving electrical equipment.",
    "question": "What should you avoid?",
    "options": [
      "Raising the alarm and leaving",
      "Using water on live electrical equipment",
      "Calling emergency services from safety"
    ],
    "correct": 1,
    "why": "Never throw water on live electrical equipment. Raise the alarm, evacuate, and call emergency services."
  },
  {
    "category": "Earthquakes",
    "title": "Outside during shaking",
    "desc": "An earthquake begins while you are outdoors.",
    "question": "Where should you move?",
    "options": [
      "Away from buildings, trees, streetlights, and power lines",
      "Under a balcony",
      "Close to glass shopfronts"
    ],
    "correct": 0,
    "why": "Move to an open area away from things that could fall. Protect your head and neck."
  },
  {
    "category": "Earthquakes",
    "title": "Aftershocks",
    "desc": "You feel another tremor after the main earthquake.",
    "question": "What should you remember?",
    "options": [
      "Aftershocks can happen; protect yourself again",
      "The first earthquake means all danger is over",
      "Stand beside damaged walls"
    ],
    "correct": 0,
    "why": "Aftershocks may occur. Drop, cover, and hold on again, and stay away from damaged structures."
  },
  {
    "category": "Weather",
    "title": "Cyclone warning",
    "desc": "A cyclone warning is issued for your area.",
    "question": "What is the best plan?",
    "options": [
      "Follow official shelter or evacuation instructions",
      "Go to the beach to watch waves",
      "Ignore updates once the wind starts"
    ],
    "correct": 0,
    "why": "Follow official updates and evacuation instructions. Stay away from coasts and exposed areas."
  },
  {
    "category": "Weather",
    "title": "Thunderstorm",
    "desc": "You are swimming and hear thunder.",
    "question": "What should you do?",
    "options": [
      "Get out of the water and move to a safe substantial shelter",
      "Stay in the water until rain begins",
      "Hold a metal umbrella"
    ],
    "correct": 0,
    "why": "Water and open areas are dangerous during lightning. Move to a substantial building or enclosed vehicle."
  },
  {
    "category": "Preparedness",
    "title": "Family meeting point",
    "desc": "Your family gets separated during an emergency.",
    "question": "What helps most?",
    "options": [
      "A pre-agreed meeting place and contact plan",
      "Everyone searching in different directions",
      "Posting personal details publicly"
    ],
    "correct": 0,
    "why": "Agree on a safe meeting place and communication plan before an emergency."
  },
  {
    "category": "Preparedness",
    "title": "Emergency information",
    "desc": "You share your location with responders.",
    "question": "What detail is especially helpful?",
    "options": [
      "A clear address or landmark and what happened",
      "A guess about the nearest city only",
      "An unrelated photo"
    ],
    "correct": 0,
    "why": "Give a precise location, nearby landmark, type of emergency, and any immediate hazards."
  },
  {
    "category": "Road safety",
    "title": "Railway crossing",
    "desc": "A railway crossing warning is active.",
    "question": "What should you do?",
    "options": [
      "Wait until the warning ends and it is safe to cross",
      "Weave around the barrier",
      "Follow another vehicle through"
    ],
    "correct": 0,
    "why": "Never cross against a warning or around a barrier. Wait until the crossing is fully clear and safe."
  },
  {
    "category": "Road safety",
    "title": "Power line down",
    "desc": "A fallen power line is lying near a road.",
    "question": "What should you do?",
    "options": [
      "Stay well away and alert emergency services or the electricity provider",
      "Touch it with a wooden stick",
      "Walk over it carefully"
    ],
    "correct": 0,
    "why": "Treat fallen wires as live. Keep others away and report the hazard from a safe distance."
  },
  {
    "category": "First aid",
    "title": "Seizure",
    "desc": "Someone nearby is having a seizure.",
    "question": "What should you do?",
    "options": [
      "Clear nearby hazards, protect their head, and time the seizure",
      "Hold them down firmly",
      "Put an object in their mouth"
    ],
    "correct": 0,
    "why": "Do not restrain them or put anything in their mouth. Protect from nearby hazards and seek emergency help when needed."
  },
  {
    "category": "First aid",
    "title": "Possible stroke",
    "desc": "A person suddenly has facial drooping and trouble speaking.",
    "question": "What should you do?",
    "options": [
      "Wait an hour to see if it passes",
      "Call emergency services immediately and note when symptoms began",
      "Give them food"
    ],
    "correct": 1,
    "why": "These can be signs of a stroke. Time matters: call emergency services immediately and note symptom start time."
  },
  {
    "category": "Preparedness",
    "title": "Phone battery",
    "desc": "You may need to evacuate and your phone battery is low.",
    "question": "What is a useful step?",
    "options": [
      "Save battery, share your plan, and keep emergency contacts accessible",
      "Stream videos to stay calm",
      "Delete all emergency information"
    ],
    "correct": 0,
    "why": "Conserve battery and keep essential contact and location information available."
  },
  {
    "category": "Floods",
    "title": "Electrical hazard after flood",
    "desc": "Water has entered a building and electrical outlets may be wet.",
    "question": "What should you do?",
    "options": [
      "Avoid touching electrical equipment and get qualified help",
      "Switch appliances on to test them",
      "Walk barefoot through the water"
    ],
    "correct": 0,
    "why": "Do not touch wet electrical equipment. Keep away and contact qualified professionals or authorities."
  },
  {
    "category": "Weather",
    "title": "Landslide warning",
    "desc": "Heavy rain has triggered a landslide warning near a slope.",
    "question": "What should you do?",
    "options": [
      "Stay away from the slope and follow evacuation advice",
      "Go closer to take photos",
      "Stand below the slope"
    ],
    "correct": 0,
    "why": "Avoid steep slopes and areas with warning signs. Follow official evacuation instructions."
  },
  {
    "category": "Preparedness",
    "title": "Reliable information",
    "desc": "A dramatic emergency message appears in a group chat.",
    "question": "What should you do before sharing it?",
    "options": [
      "Check official sources and avoid forwarding unverified claims",
      "Forward it to everyone immediately",
      "Change the details to sound more urgent"
    ],
    "correct": 0,
    "why": "Misinformation can put people at risk. Verify alerts through official sources before sharing."
  },
  {"category": "First aid", "title": "Minor cut", "desc": "A person has a small cut.", "question": "What is a sensible first step?", "options": ["Wash your hands, then apply gentle pressure with clean gauze", "Rub dirt into it", "Ignore heavy bleeding"], "correct": 0, "why": "Clean hands and gentle pressure help manage a minor cut. Seek care if bleeding is severe or the wound is deep."},
  {"category": "First aid", "title": "Nosebleed", "desc": "A friend has a nosebleed.", "question": "What should they do?", "options": ["Lean forward and pinch the soft part of the nose", "Tilt the head far back", "Lie flat"], "correct": 0, "why": "Leaning forward and pinching the soft part helps. Seek medical help if bleeding is heavy or does not stop."},
  {"category": "First aid", "title": "Feeling overheated", "desc": "A classmate feels overheated and dizzy.", "question": "What should you do?", "options": ["Move them to a cool place and get an adult or medical help", "Make them keep running", "Give them an energy drink and send them away"], "correct": 0, "why": "Stop activity, cool the person, and get help. Confusion or collapse needs urgent emergency care."},
  {"category": "First aid", "title": "Possible poisoning", "desc": "Someone may have swallowed a household chemical.", "question": "What is safest?", "options": ["Contact emergency services or poison advice; do not induce vomiting", "Make them vomit", "Give random medicines"], "correct": 0, "why": "Get expert help immediately. Do not induce vomiting or give anything unless professionals advise it."},
  {"category": "First aid", "title": "Eye irritation", "desc": "Dust gets into someone’s eye.", "question": "What should they do?", "options": ["Rinse gently with clean running water; do not rub", "Rub hard", "Use sharp tools to remove it"], "correct": 0, "why": "Gentle rinsing may help with loose dust. Seek urgent care for embedded objects, pain, or vision changes."},
  {"category": "First aid", "title": "Sprained ankle", "desc": "A person twists an ankle and has pain.", "question": "What is a sensible response?", "options": ["Stop activity, rest, and seek advice if pain or swelling is significant", "Force them to walk it off", "Massage forcefully"], "correct": 0, "why": "Stop activity and protect the area. Significant pain, swelling, or inability to bear weight needs medical assessment."},
  {"category": "First aid", "title": "Unwell in hot weather", "desc": "A person is weak after being in the sun.", "question": "What should happen first?", "options": ["Move to shade or a cool place and seek help if symptoms are serious", "Leave them in the sun", "Make them exercise"], "correct": 0, "why": "Cooling and rest are important. Severe symptoms such as confusion or fainting need urgent help."},
  {"category": "First aid", "title": "Medication uncertainty", "desc": "You find an unlabelled tablet.", "question": "What should you do?", "options": ["Do not take it; ask a trusted adult or pharmacist", "Guess what it is", "Share it with a friend"], "correct": 0, "why": "Never take unidentified medicine. Ask a responsible adult and a qualified pharmacist or clinician."},
  {"category": "First aid", "title": "Helping safely", "desc": "You see an injured person near broken glass.", "question": "What comes first?", "options": ["Check scene safety and call for trained help", "Rush through the glass", "Move everything without checking"], "correct": 0, "why": "Do not become another casualty. Check hazards and follow emergency dispatcher instructions."},
  {"category": "First aid", "title": "Emergency information", "desc": "You call for an ambulance.", "question": "What information is useful?", "options": ["Exact location, what happened, and number of people needing help", "Only your first name", "An unverified guess about the cause"], "correct": 0, "why": "Clear location and concise facts help dispatchers send appropriate assistance."},
  {"category": "Fire safety", "title": "Kitchen smoke", "desc": "A pan begins smoking heavily.", "question": "What should you do?", "options": ["Alert others and leave if there is danger; call fire services from safety", "Pour water on burning oil", "Hide in a cupboard"], "correct": 0, "why": "Never pour water on an oil or grease fire. Evacuate if unsafe and call professionals."},
  {"category": "Fire safety", "title": "Fire alarm", "desc": "A fire alarm sounds at school.", "question": "What is the right response?", "options": ["Follow the evacuation plan calmly and go to the assembly point", "Assume it is a drill and stay", "Use the lift"], "correct": 0, "why": "Treat alarms seriously and follow staff instructions and the established evacuation route."},
  {"category": "Fire safety", "title": "Smoke detector", "desc": "A smoke alarm is beeping repeatedly.", "question": "What should you do?", "options": ["Tell an adult or building manager and check the alarm safely", "Remove its battery and forget it", "Cover it permanently"], "correct": 0, "why": "A working alarm is important. Report faults and never disable it as a solution."},
  {"category": "Fire safety", "title": "Electrical fire", "desc": "An electrical appliance catches fire.", "question": "What is safest?", "options": ["Keep away, evacuate if needed, and call fire services", "Throw water on it", "Touch the plug with wet hands"], "correct": 0, "why": "Water can conduct electricity. Keep away and let trained responders handle the fire."},
  {"category": "Fire safety", "title": "Evacuation route", "desc": "You are unsure which exit to use.", "question": "What should guide you?", "options": ["Marked safe exits and staff or responder directions", "A locked door", "A route through smoke"], "correct": 0, "why": "Use marked safe exits and follow the building evacuation plan."},
  {"category": "Fire safety", "title": "After evacuation", "desc": "You have reached the assembly point.", "question": "What next?", "options": ["Stay there for roll call and do not re-enter", "Go back for a bag", "Leave without telling anyone"], "correct": 0, "why": "Stay at the assembly point so staff can account for everyone. Never re-enter until cleared."},
  {"category": "Fire safety", "title": "Gas smell", "desc": "You smell gas indoors.", "question": "What is a safe response?", "options": ["Leave the area, avoid operating switches, and call the gas service from outside", "Light a match to check", "Turn electrical switches on and off"], "correct": 0, "why": "Avoid flames and electrical switches. Leave and contact the appropriate emergency service from outside."},
  {"category": "Fire safety", "title": "Fire door", "desc": "A fire door is propped open.", "question": "Why should it be closed?", "options": ["It helps slow smoke and fire spread", "It makes alarms louder", "It is only decorative"], "correct": 0, "why": "Fire doors help compartmentalise smoke and fire. Report doors that cannot close properly."},
  {"category": "Fire safety", "title": "Crowded exit", "desc": "People are rushing toward one exit.", "question": "What should you do?", "options": ["Stay calm, avoid pushing, and follow the evacuation marshal", "Push others aside", "Stop in the doorway"], "correct": 0, "why": "Pushing can cause falls and block exits. Follow trained staff and keep moving calmly."},
  {"category": "Fire safety", "title": "Fireworks warning", "desc": "You see an unsafe fireworks activity nearby.", "question": "What is best?", "options": ["Keep a safe distance and alert a responsible adult or authorities", "Go closer to film", "Try to handle the fireworks"], "correct": 0, "why": "Do not approach or handle fireworks. Keep away and let responsible adults or authorities respond."},
  {"category": "Floods", "title": "Rising water", "desc": "Water is rising near your home.", "question": "What should you do?", "options": ["Move to higher safe ground when advised and follow official alerts", "Go into the water to inspect", "Wait in a basement"], "correct": 0, "why": "Follow official evacuation advice and avoid basements or floodwater."},
  {"category": "Floods", "title": "Flooded bridge", "desc": "A bridge is covered by floodwater.", "question": "What is safest?", "options": ["Do not cross; choose a safe alternative route", "Test it on foot", "Drive fast through it"], "correct": 0, "why": "Floodwater can hide damage and sweep people or vehicles away. Never cross."},
  {"category": "Floods", "title": "Drinking water", "desc": "Flooding may have contaminated tap water.", "question": "What should you do?", "options": ["Follow local boil-water or safe-water advisories", "Assume it is safe", "Drink water from flood pools"], "correct": 0, "why": "Use water declared safe by authorities and follow local public-health instructions."},
  {"category": "Floods", "title": "Evacuation bag", "desc": "Your family is preparing to leave due to a flood warning.", "question": "What is useful?", "options": ["Take essentials only if safe and leave promptly as instructed", "Spend hours packing valuables", "Return to collect items after leaving"], "correct": 0, "why": "Do not delay evacuation. Take essential supplies only when it is safe to do so."},
  {"category": "Floods", "title": "Flooded basement", "desc": "Water is entering a basement.", "question": "What should you do?", "options": ["Stay out and move to a safer higher area", "Go down to save belongings", "Touch electrical equipment"], "correct": 0, "why": "Basements can flood rapidly and contain electrical hazards. Stay out and call for help."},
  {"category": "Floods", "title": "After evacuation", "desc": "Authorities say your area is not yet safe to return.", "question": "What should you do?", "options": ["Wait for official clearance", "Return secretly", "Ignore barriers"], "correct": 0, "why": "Return only when authorities say it is safe."},
  {"category": "Floods", "title": "Fast-moving water", "desc": "A stream is rising after heavy rain.", "question": "What is the safe choice?", "options": ["Move away from banks and low crossings", "Stand on a slippery bank", "Try to measure the flow"], "correct": 0, "why": "Rising water can change quickly. Move away and heed warnings."},
  {"category": "Floods", "title": "Wet documents", "desc": "Important documents may be damaged in a flood.", "question": "What is the priority?", "options": ["Protect people first; documents are secondary", "Risk entering floodwater to save papers", "Delay evacuation"], "correct": 0, "why": "Life safety comes first. Never risk entering floodwater for belongings."},
  {"category": "Floods", "title": "Flood debris", "desc": "You see debris and mud after water recedes.", "question": "What should you assume?", "options": ["Hidden sharp objects and contamination may remain", "Everything is clean", "Barefoot walking is fine"], "correct": 0, "why": "Wear suitable protection and follow local cleanup guidance; avoid unknown hazards."},
  {"category": "Floods", "title": "Flood warning source", "desc": "A social post says a dam has failed.", "question": "What should you do?", "options": ["Verify through official authorities before sharing", "Forward immediately", "Add dramatic details"], "correct": 0, "why": "Check official emergency management and local authority channels."},
  {"category": "Earthquakes", "title": "Near a window", "desc": "You are indoors near glass when shaking starts.", "question": "What should you do?", "options": ["Move away from glass and drop, cover, and hold on", "Stand beside the window", "Run outside during shaking"], "correct": 0, "why": "Protect your head and neck and stay away from windows until shaking stops."},
  {"category": "Earthquakes", "title": "Outside during shaking", "desc": "You are outdoors when an earthquake begins.", "question": "Where should you move?", "options": ["Open space away from buildings, trees, and power lines", "Under a balcony", "Beside a wall"], "correct": 0, "why": "Move to open space and protect your head from falling objects."},
  {"category": "Earthquakes", "title": "In a vehicle", "desc": "You are in a car when shaking starts.", "question": "What should the driver do?", "options": ["Pull over safely away from bridges and wires; remain inside", "Stop under an overpass", "Drive quickly through the shaking"], "correct": 0, "why": "Stop in a clear location and remain in the vehicle until shaking ends."},
  {"category": "Earthquakes", "title": "Aftershock", "desc": "A smaller tremor follows a large earthquake.", "question": "What should you remember?", "options": ["Aftershocks can happen; stay alert and protect yourself", "The danger is definitely over", "Use damaged lifts"], "correct": 0, "why": "Aftershocks may cause further damage. Follow official updates and avoid damaged structures."},
  {"category": "Earthquakes", "title": "Damaged building", "desc": "You notice new cracks and damage after shaking.", "question": "What should you do?", "options": ["Leave carefully if safe and do not re-enter until cleared", "Stay inside to inspect every room", "Use the lift"], "correct": 0, "why": "Damaged buildings may be unsafe. Follow responders and official inspection advice."},
  {"category": "Earthquakes", "title": "School drill", "desc": "Your school practises earthquake safety.", "question": "Why practise?", "options": ["It helps people respond calmly and remember safe actions", "It guarantees no injury", "It replaces official advice"], "correct": 0, "why": "Drills help people learn and practise actions before an emergency."},
  {"category": "Earthquakes", "title": "Falling objects", "desc": "Books and objects begin falling during shaking.", "question": "How can you reduce risk?", "options": ["Take cover under sturdy furniture and protect head and neck", "Stand below shelves", "Run toward glass"], "correct": 0, "why": "Cover protects from falling objects. Hold on until the shaking stops."},
  {"category": "Earthquakes", "title": "Coastal earthquake", "desc": "A strong earthquake occurs near the coast.", "question": "What should people do if a tsunami warning is issued?", "options": ["Move inland or to higher ground as directed", "Go to the beach to watch", "Wait for waves to appear"], "correct": 0, "why": "Follow tsunami evacuation instructions immediately; do not wait to see a wave."},
  {"category": "Earthquakes", "title": "Gas concern", "desc": "You suspect a gas leak after an earthquake.", "question": "What should you do?", "options": ["Leave, avoid flames and switches, and report it from safety", "Light a candle", "Operate appliances to test them"], "correct": 0, "why": "Avoid ignition sources and contact emergency services or the utility from a safe place."},
  {"category": "Earthquakes", "title": "Emergency radio", "desc": "Mobile networks are unavailable after a quake.", "question": "What may help receive updates?", "options": ["A battery-powered or hand-crank radio", "Repeatedly refreshing a disconnected app", "Spreading rumours"], "correct": 0, "why": "A radio may receive official information when mobile networks are disrupted."},
  {"category": "Road safety", "title": "Helmet use", "desc": "You are riding a bicycle.", "question": "What is a good safety habit?", "options": ["Wear a correctly fitted helmet and follow traffic rules", "Ride against traffic", "Use a phone while moving"], "correct": 0, "why": "A properly fitted helmet and predictable, lawful riding reduce risk."},
  {"category": "Road safety", "title": "Crossing road", "desc": "You need to cross a busy road.", "question": "What should you do?", "options": ["Use a marked crossing and check traffic in all directions", "Run between parked vehicles", "Look only one way"], "correct": 0, "why": "Use designated crossings and make sure traffic has stopped before crossing."},
  {"category": "Road safety", "title": "Night visibility", "desc": "You walk near roads after dark.", "question": "How can you be more visible?", "options": ["Use reflective or light-coloured clothing and walk in safe areas", "Wear all dark clothing", "Walk in the road"], "correct": 0, "why": "Visibility helps drivers see pedestrians. Use footpaths where available."},
  {"category": "Road safety", "title": "Emergency vehicle", "desc": "An ambulance approaches with siren and lights.", "question": "What should road users do?", "options": ["Give way safely according to local traffic rules", "Race it", "Block its path"], "correct": 0, "why": "Make room safely and predictably; do not create another hazard."},
  {"category": "Road safety", "title": "Distracted driving", "desc": "A driver looks at a phone while moving.", "question": "What is the safe rule?", "options": ["Do not use a handheld phone while driving", "Text only at junctions", "Hold the phone lower"], "correct": 0, "why": "Driving requires attention. Stop in a safe place before using a phone."},
  {"category": "Road safety", "title": "School bus", "desc": "A school bus has stopped to let students off.", "question": "What should nearby drivers do?", "options": ["Slow down and follow local school-bus stopping rules", "Overtake without checking", "Sound the horn continuously"], "correct": 0, "why": "Children may cross unexpectedly. Follow local law and stop when required."},
  {"category": "Road safety", "title": "Rainy road", "desc": "The road is wet and visibility is poor.", "question": "What should a driver do?", "options": ["Slow down, increase following distance, and use lights appropriately", "Drive faster", "Brake sharply without warning"], "correct": 0, "why": "Wet roads reduce grip. Adjust speed and distance to conditions."},
  {"category": "Road safety", "title": "Vehicle breakdown", "desc": "Your vehicle breaks down on a busy road.", "question": "What is a safe priority?", "options": ["Move to a safe place if possible and alert roadside assistance", "Stand in a traffic lane", "Try repairs in moving traffic"], "correct": 0, "why": "Protect people from traffic first. Use hazard signals and seek professional assistance."},
  {"category": "Road safety", "title": "Seat for children", "desc": "A young child is travelling in a car.", "question": "What is safest?", "options": ["Use an age- and size-appropriate child restraint correctly", "Hold the child on a lap", "Let the child stand"], "correct": 0, "why": "Use a properly fitted child restraint that follows local requirements."},
  {"category": "Road safety", "title": "Railway crossing", "desc": "A railway barrier is down.", "question": "What should you do?", "options": ["Wait behind the barrier until it fully opens", "Weave around it", "Follow another vehicle across"], "correct": 0, "why": "Never cross when barriers or signals warn of an approaching train."},
  {"category": "Weather", "title": "Cyclone alert", "desc": "Authorities issue a cyclone warning.", "question": "What should you do?", "options": ["Follow evacuation and shelter instructions and monitor official updates", "Go outdoors to watch", "Ignore the alert"], "correct": 0, "why": "Prepare early and follow local emergency management instructions."},
  {"category": "Weather", "title": "Thunderstorm", "desc": "Thunder is heard while you are outside.", "question": "What should you do?", "options": ["Go indoors or into a hard-topped vehicle", "Stay under a lone tree", "Use an open sports field"], "correct": 0, "why": "Seek substantial shelter promptly and wait until the storm has passed."},
  {"category": "Weather", "title": "Cold exposure", "desc": "Someone is very cold and confused outdoors.", "question": "What is appropriate?", "options": ["Get them sheltered and seek urgent medical help", "Leave them outside", "Give alcohol"], "correct": 0, "why": "Confusion can signal a serious cold-related emergency. Seek urgent help and warm them gradually."},
  {"category": "Weather", "title": "Strong winds", "desc": "A severe wind warning is active.", "question": "Where is safer?", "options": ["Indoors, away from windows", "Under a tree", "Near loose outdoor objects"], "correct": 0, "why": "Stay inside and away from windows; avoid exposed areas and loose debris."},
  {"category": "Weather", "title": "Dense fog", "desc": "Visibility on the road becomes very poor.", "question": "What should drivers do?", "options": ["Reduce speed, increase distance, and use appropriate lights", "Use high speed to exit quickly", "Stop in a live lane"], "correct": 0, "why": "Drive slowly and cautiously; if stopping, move completely off the roadway safely."},
  {"category": "Weather", "title": "Heat alert", "desc": "An official heat alert is announced.", "question": "What is a sensible plan?", "options": ["Limit strenuous outdoor activity and check on vulnerable people", "Plan a midday sports event", "Avoid drinking water"], "correct": 0, "why": "Follow public-health advice, stay cool, and check on people who may need help."},
  {"category": "Weather", "title": "Landslide signs", "desc": "You notice cracks and unusual movement on a hillside after rain.", "question": "What should you do?", "options": ["Move away and report it; follow official warnings", "Stand below it", "Walk across the slope"], "correct": 0, "why": "Leave the hazard area and alert authorities from a safe location."},
  {"category": "Weather", "title": "Dust storm", "desc": "A dust storm reduces visibility outdoors.", "question": "What should you do?", "options": ["Go indoors, close windows, and follow local health advice", "Stay outside to film", "Stand near traffic"], "correct": 0, "why": "Shelter indoors and reduce exposure to dust."},
  {"category": "Weather", "title": "Weather information", "desc": "Two forecasts disagree about a severe storm.", "question": "Which should guide emergency action?", "options": ["Official local meteorological and emergency authority alerts", "An anonymous forwarded message", "A guess from a friend"], "correct": 0, "why": "Use official local warnings and updates for decisions."},
  {"category": "Weather", "title": "Lightning after storm", "desc": "The rain stops but thunder is still audible.", "question": "Is it safe to resume outdoor play?", "options": ["No; wait until the recommended time after the last thunder", "Yes, immediately", "Stand under a tree"], "correct": 0, "why": "Lightning can remain a danger after rain stops. Follow the 30-minute rule or local guidance."},
  {"category": "Preparedness", "title": "Family meeting point", "desc": "Your family creates an emergency plan.", "question": "What is useful?", "options": ["Choose a familiar meeting place and backup contact", "Keep the plan secret", "Choose a place no one can find"], "correct": 0, "why": "A shared plan helps family members reconnect if separated."},
  {"category": "Preparedness", "title": "Emergency numbers", "desc": "You move to a new area.", "question": "What should you check?", "options": ["Local emergency numbers and official alert channels", "Only numbers from old messages", "Random online comments"], "correct": 0, "why": "Emergency numbers and services vary by location. Verify with official sources."},
  {"category": "Preparedness", "title": "Power outage", "desc": "Electricity fails during a storm.", "question": "What is a useful preparation?", "options": ["Keep a torch, spare batteries, and charged power bank", "Use candles near curtains", "Touch damaged wires"], "correct": 0, "why": "Use safer lighting and keep away from damaged electrical equipment."},
  {"category": "Preparedness", "title": "Important medicines", "desc": "A family member needs regular prescribed medicine.", "question": "What should the emergency plan include?", "options": ["A safe supply and prescription details as advised by their clinician", "Unlabelled loose tablets", "Someone else’s medicine"], "correct": 0, "why": "Plan with a healthcare professional and keep medicines labelled and stored safely."},
  {"category": "Preparedness", "title": "Pet evacuation", "desc": "Your family has a pet during an evacuation.", "question": "What should you plan?", "options": ["A carrier, leash, food, water, and pet records", "Leave the pet loose outside", "Return to a danger zone later"], "correct": 0, "why": "Plan pet transport and supplies ahead of time and follow evacuation instructions."},
  {"category": "Preparedness", "title": "Emergency documents", "desc": "You prepare important documents for emergencies.", "question": "How can you protect them?", "options": ["Keep copies securely in a waterproof folder or safe digital backup", "Post identity documents publicly", "Leave originals in flood-prone areas"], "correct": 0, "why": "Secure copies can help with recovery while protecting personal information."},
  {"category": "Preparedness", "title": "Power bank", "desc": "You are preparing an emergency kit.", "question": "What should you remember about a power bank?", "options": ["Keep it charged and store it safely", "Use a swollen or damaged battery", "Leave it in extreme heat"], "correct": 0, "why": "Use undamaged batteries and follow the manufacturer’s storage and charging guidance."},
  {"category": "Preparedness", "title": "Neighbour support", "desc": "An older neighbour may need help during evacuation.", "question": "What is a good step before a disaster?", "options": ["Ask how they prefer to receive help and include them in planning", "Assume they cannot decide", "Wait until roads are flooded"], "correct": 0, "why": "Agreeing on support in advance respects their choices and improves preparedness."},
  {"category": "Preparedness", "title": "Emergency alert", "desc": "Your phone receives an official public warning.", "question": "What should you do?", "options": ["Read the full instructions and act on local guidance", "Dismiss it without reading", "Share a cropped screenshot without context"], "correct": 0, "why": "Read the source, location, and action requested; follow official directions."},
  {"category": "Preparedness", "title": "Practice drill", "desc": "Your family practises an evacuation route.", "question": "What makes the drill useful?", "options": ["Review the route, meeting point, and any barriers afterwards", "Race and push each other", "Never discuss what happened"], "correct": 0, "why": "A calm review helps identify improvements before a real emergency."},
]

function Practice(){
 const [idx,setIdx]=useState(0); const [answer,setAnswer]=useState<number|null>(null); const [score,setScore]=useState(0); const [finished,setFinished]=useState(false); const [setNo,setSetNo]=useState(0);
 const [language,setLanguage]=useState<string>(()=>{try{return localStorage.getItem('lifeline-language')||'en'}catch{return 'en'}});
 useEffect(()=>{const update=()=>{try{setLanguage(localStorage.getItem('lifeline-language')||'en')}catch{setLanguage('en')}};window.addEventListener('lifeline-language-change',update);return()=>window.removeEventListener('lifeline-language-change',update)},[])
 const t=(value:string)=>translateText(value,language as LanguageCode);
 const setQuestions=useMemo(()=>cases.slice(0,100).slice(setNo*10,setNo*10+10),[setNo]); const c=setQuestions[idx];
 const choose=(n:number)=>{if(answer!==null)return;setAnswer(n);if(n===c.correct)setScore(s=>s+1)};
 const next=()=>{if(idx===9)setFinished(true);else{setIdx(i=>i+1);setAnswer(null)}};
 const reset=()=>{setIdx(0);setAnswer(null);setScore(0);setFinished(false)};
 const chooseSet=(n:number)=>{setSetNo(n);reset()};
 const percent=score*10; const feedback=percent===100?'Outstanding! Perfect score.':percent>=90?'Excellent work! Your emergency-safety knowledge is very strong.':percent>=80?'Wonderful work! You have a strong understanding.':percent>=70?'Very good! A little more revision will help.':percent>=60?'Good effort! Review the explanations to strengthen your knowledge.':percent>=40?'You are learning. Practise again and focus on the explanations.':'Keep practising. Take your time, review the safety notes, and try again.';
 const feedbackDetail=percent===100?'Excellent work—keep refreshing these skills.':percent>=90?'You have mastered this set. Keep practising to retain the knowledge.':percent>=80?'You did very well. A little revision will make your knowledge even stronger.':percent>=70?'You are close to an excellent score. Review the few missed answers.':percent>=60?'You have a good start. Revisit the questions you missed.':percent>=40?'Review the safety guidance carefully, then try this set again.':'No worries—practice is how we learn. Read each explanation and try again.';
 const totalSets=10;
 return <main className="mx-auto max-w-5xl px-4 pb-28 pt-8">
  <div className="rounded-[2rem] bg-gradient-to-br from-neutral-950 via-slate-900 to-amber-950 p-8 text-white sm:p-10">
   <p className="text-xs font-bold uppercase tracking-[.25em] text-amber-300">{t('Practice lab · no real alerts')}</p>
   <h1 className="mt-3 font-display text-4xl font-extrabold sm:text-5xl">{t('Train for the moment you hope never comes.')}</h1>
   <p className="mt-4 max-w-2xl text-slate-300">{t('100 questions · 10 practice sets · 10 questions in each set. Nothing here calls anyone or sends an SOS.')}</p>
   <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-5">{Array.from({length:totalSets},(_,i)=><button key={i} onClick={()=>chooseSet(i)} className={`rounded-xl px-3 py-3 text-sm font-bold ${setNo===i?'bg-amber-300 text-neutral-950':'border border-white/20 bg-white/5 text-white hover:bg-white/10'}`}>{t('Set')} {i+1}</button>)}</div>
  </div>
  {finished?<section className="mt-6 rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-slate-200"><Trophy className="mx-auto text-amber-500" size={48}/><h2 className="mt-4 font-display text-3xl font-extrabold">{t('Practice complete')}</h2><p className="mt-2 text-slate-600">{t('Set')} {setNo+1}: {score} / 10 ({percent}%)</p><p className="mt-3 text-xl font-extrabold text-amber-700">{t(feedback)}</p><p className="mt-2 text-sm text-slate-500">{t(feedbackDetail)}</p><p className="mt-2 text-sm text-slate-500">{t('This score is for learning, not a medical qualification.')}</p><div className="mt-5 flex flex-wrap justify-center gap-2"><button onClick={reset} className="inline-flex items-center gap-2 rounded-full bg-slate-900 px-5 py-3 font-bold text-white"><RotateCcw size={17}/>{t('Try this set again')}</button>{setNo<9&&<button onClick={()=>chooseSet(setNo+1)} className="rounded-full bg-amber-400 px-5 py-3 font-bold text-neutral-950">{t('Next set')}</button>}</div></section>:<div className="mt-6 grid gap-5 md:grid-cols-5"><section className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:col-span-3"><div className="flex items-center justify-between gap-3"><span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-bold text-amber-900">{t('Set')} {setNo+1} · {t('Question')} {idx+1} / 10 · {t(c.category)}</span><ClipboardCheck className="text-amber-700"/></div><div className="mt-4 h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-amber-500 transition-all" style={{width:`${((idx+(answer!==null?1:0))/10)*100}%`}}/></div><h2 className="mt-5 font-display text-2xl font-bold">{t(c.title)}</h2><p className="mt-2 text-slate-600">{t(c.desc)}</p><h3 className="mt-6 font-bold">{t(c.question)}</h3><div className="mt-3 space-y-2">{c.options.map((o,i)=><button key={o} onClick={()=>choose(i)} disabled={answer!==null} className={`w-full rounded-2xl border p-4 text-left text-sm font-semibold transition ${answer===null?'border-slate-200 hover:border-amber-300 hover:bg-amber-50':i===c.correct?'border-emerald-300 bg-emerald-50 text-emerald-900':answer===i?'border-rose-300 bg-rose-50 text-rose-900':'border-slate-100 text-slate-500'}`}>{t(o)}</button>)}</div>{answer!==null&&<div className="mt-4 rounded-2xl bg-slate-50 p-4"><p className={`flex items-center gap-2 font-bold ${answer===c.correct?'text-emerald-700':'text-rose-700'}`}>{answer===c.correct?<CheckCircle2 size={18}/>:<XCircle size={18}/>} {t(answer===c.correct?'Correct choice':'Review this choice')}</p><p className="mt-2 text-sm leading-relaxed text-slate-600">{t(c.why)}</p><button onClick={next} className="mt-4 rounded-full bg-slate-900 px-5 py-2.5 text-sm font-bold text-white">{t(idx===9?'See result':'Next question')}</button></div>}</section>
  <aside className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:col-span-2"><HeartPulse className="text-amber-600" size={30}/><h2 className="mt-3 font-display text-xl font-bold">{t('Learn safely')}</h2><p className="mt-2 text-sm leading-relaxed text-slate-600">{t('This is educational practice, not a medical assessment or substitute for certified first-aid training. In a real emergency, contact local emergency services and follow trained responders.')}</p><div className="mt-5 rounded-2xl bg-rose-50 p-4"><p className="flex items-center gap-2 font-bold text-rose-800"><Siren size={18}/> {t('Need real help?')}</p><p className="mt-1 text-sm text-rose-800">{t('Leave practice and use the real emergency flow only when needed.')}</p><Link to="/monitor" className="mt-3 inline-flex rounded-full bg-rose-600 px-4 py-2 text-sm font-bold text-white">{t('Open monitor')}</Link></div><div className="mt-4 flex items-start gap-2 text-sm text-slate-500"><MapPin size={17} className="mt-0.5 shrink-0"/> {t('Know your location and tell responders where help is needed.')}</div><div className="mt-5 text-xs text-slate-400">{t('Choose a set above to practise all 100 questions at your own pace.')}</div></aside></div>}
 </main>
}
