import type { Threshold, VitalKey } from './types'

/** Broad input-sanity bounds, not medical recommendations or diagnostic limits. */
export const THRESHOLD_BOUNDS: Record<VitalKey, { min: number; max: number }> = {
  bp: { min: 30, max: 300 },
  glucose: { min: 10, max: 1500 },
  hr: { min: 15, max: 300 },
  spo2: { min: 50, max: 100 },
}

export function validateThresholdChange(
  key: VitalKey,
  field: 'below' | 'above' | 'above2',
  value: number | null,
  current: Threshold,
): string | null {
  if (value === null) return null // Blank explicitly disables that direction.
  if (!Number.isFinite(value)) return 'Enter a finite number.'
  const bounds = THRESHOLD_BOUNDS[key]
  if (value < bounds.min || value > bounds.max) {
    return `${key === 'spo2' ? 'Oxygen' : key === 'hr' ? 'Heart rate' : key === 'bp' ? 'Blood pressure' : 'Blood sugar'} threshold must be between ${bounds.min} and ${bounds.max}. These are input-sanity bounds, not medical advice.`
  }
  if (key === 'spo2' && field !== 'below') return 'Oxygen uses a low threshold only.'
  if (field === 'below' && current.above !== null && current.above !== undefined && value >= current.above) {
    return 'The low threshold must be lower than the high threshold.'
  }
  if (field === 'above' && current.below !== null && current.below !== undefined && value <= current.below) {
    return 'The high threshold must be higher than the low threshold.'
  }
  if (field === 'above2' && key !== 'bp') return 'A second threshold is only used for blood pressure.'
  return null
}

/** Sanitize persisted values so corrupted/old local storage cannot inject absurd thresholds. */
export function sanitizeThresholds(input: unknown, defaults: Record<VitalKey, Threshold>): Record<VitalKey, Threshold> {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return defaults
  const source = input as Partial<Record<VitalKey, Partial<Threshold>>>
  const result = Object.fromEntries((Object.keys(defaults) as VitalKey[]).map((key) => [key, { ...defaults[key] }])) as Record<VitalKey, Threshold>
  for (const key of Object.keys(defaults) as VitalKey[]) {
    const candidate = source[key]
    if (!candidate || typeof candidate !== 'object') continue
    for (const field of ['below', 'above', 'above2'] as const) {
      if (!(field in candidate)) continue
      const value = candidate[field]
      if (value === null) { result[key][field] = null; continue }
      if (typeof value !== 'number' || !Number.isFinite(value)) continue
      if (validateThresholdChange(key, field, value, result[key]) === null) result[key][field] = value
    }
    if (result[key].below != null && result[key].above != null && result[key].below! >= result[key].above!) {
      result[key] = { ...defaults[key] }
    }
  }
  return result
}
