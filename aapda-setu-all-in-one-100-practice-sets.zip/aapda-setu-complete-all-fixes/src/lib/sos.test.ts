import { describe, expect, it } from 'vitest'
import { buildSosMessage, isValidPhone, smsHref, telHref } from './sos'

describe('Aapda Setu SOS message safety', () => {
  it('does not claim a message has already been sent', () => {
    const message = buildSosMessage(null, null)
    expect(message).toContain('NOT SENT yet')
    expect(message).not.toContain('Ravi Sharma')
  })

  it('labels test messages as tests', () => {
    expect(buildSosMessage(null, null, { test: true })).toContain('[TEST — no action needed]')
  })

  it('rejects malformed or empty phone numbers', () => {
    expect(isValidPhone('112')).toBe(true)
    expect(isValidPhone('abc')).toBe(false)
    expect(isValidPhone('+12+34')).toBe(false)
    expect(smsHref([], 'help')).toBe('')
    expect(telHref('abc')).toBe('')
  })

  it('creates phone handoff links only for valid numbers', () => {
    expect(telHref('112')).toBe('tel:112')
    expect(telHref('112 / 119')).toBe('tel:112')
    expect(telHref('000 (Mobile 112)')).toBe('tel:000')
    expect(smsHref(['abc', '+911234567890'], 'help')).toContain('sms:+911234567890')
  })
})
