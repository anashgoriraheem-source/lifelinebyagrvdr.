import { describe, expect, it } from 'vitest'
import { DEFAULT_THRESHOLDS } from './fixtures'
import { sanitizeThresholds, validateThresholdChange } from './thresholds'

describe('threshold safety validation', () => {
  it('rejects oxygen thresholds above 100%', () => {
    expect(validateThresholdChange('spo2', 'below', 105, DEFAULT_THRESHOLDS.spo2)).toContain('between 50 and 100')
  })
  it('rejects a low limit that is not lower than the high limit', () => {
    expect(validateThresholdChange('hr', 'below', 140, DEFAULT_THRESHOLDS.hr)).toContain('lower than the high threshold')
  })
  it('allows an explicit null to disable a direction', () => {
    expect(validateThresholdChange('hr', 'below', null, DEFAULT_THRESHOLDS.hr)).toBeNull()
  })
  it('falls back to defaults for absurd persisted values', () => {
    const result = sanitizeThresholds({ hr: { below: -900, above: 99999 } }, DEFAULT_THRESHOLDS)
    expect(result.hr).toEqual(DEFAULT_THRESHOLDS.hr)
  })
})
