import { addLog, appStore, set } from './store'

let watchId: number | null = null

function clearWatch() {
  if (watchId != null && typeof navigator !== 'undefined' && navigator.geolocation) {
    navigator.geolocation.clearWatch(watchId)
  }
  watchId = null
}

/** Start live GPS tracking. Safe to call repeatedly; a failed watch can be retried. */
export function startTracking() {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return
  if (!window.isSecureContext) {
    set((s) => ({ location: { ...s.location, status: 'error', error: 'Location requires a secure HTTPS page (or localhost). Open the deployed HTTPS app in your browser.' } }))
    return
  }
  if (!('geolocation' in navigator)) {
    set({ location: { status: 'unavailable', fix: null, error: 'This browser does not support location services.' } })
    return
  }
  // Do not get stuck with a dead watch after a timeout/error; allow retry.
  if (watchId != null) return

  set((s) => ({ location: { ...s.location, status: 'requesting', error: null } }))
  watchId = navigator.geolocation.watchPosition(
    (pos) => {
      const first = appStore.state.location.status !== 'tracking'
      set({
        location: {
          status: 'tracking',
          error: null,
          fix: { lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy, at: pos.timestamp },
        },
      })
      if (first) addLog('location', `Location tracking on · ±${Math.round(pos.coords.accuracy)} m`)
    },
    (err) => {
      const message = err.code === err.PERMISSION_DENIED
        ? 'Location permission denied. Allow Location for this site in your browser settings, then retry.'
        : err.code === err.POSITION_UNAVAILABLE
          ? 'Your device could not get a location fix. Turn on device Location/GPS and try outdoors.'
          : 'Location request timed out. Keep GPS on and tap Retry.'
      // A timeout or permission error should not leave a stale watch blocking retries.
      clearWatch()
      set((s) => ({
        location: {
          ...s.location,
          status: err.code === err.PERMISSION_DENIED ? 'denied' : 'error',
          error: message,
        },
      }))
    },
    { enableHighAccuracy: true, maximumAge: 0, timeout: 25000 },
  )
}

export function stopTracking() {
  clearWatch()
  set((s) => ({ location: { ...s.location, status: 'idle', error: null } }))
}
