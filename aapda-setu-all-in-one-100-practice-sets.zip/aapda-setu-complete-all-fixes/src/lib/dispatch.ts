/**
 * Client adapter for background SMS. The server endpoint must authenticate the
 * user, rate-limit incidents, validate contacts and keep provider credentials
 * server-side. This client intentionally stays disabled unless explicitly enabled.
 */
export type DispatchSmsStatus = {
  state: 'not-configured' | 'demo' | 'sending' | 'accepted' | 'failed'
  stateLabel?: string
  detail: string
  messageId?: string
}

export interface BackgroundSmsRequest {
  incidentId: string
  message: string
  contacts: Array<{ name: string; phone: string }>
  location: { lat: number; lng: number; accuracy: number; at: number } | null
  reason: string
}

export async function requestBackgroundSms(payload: BackgroundSmsRequest): Promise<DispatchSmsStatus> {
  if (import.meta.env.VITE_BACKGROUND_SMS_ENABLED !== 'true') {
    return {
      state: 'not-configured',
      stateLabel: 'Not configured',
      detail: 'Background SMS is disabled. Configure an authenticated server endpoint and SMS provider before enabling it; the app has not sent a message.',
    }
  }

  try {
    const response = await fetch('/api/emergency/dispatch', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(payload),
    })
    const body = await response.json().catch(() => ({})) as { status?: string; messageId?: string; message?: string }
    if (!response.ok || !['accepted', 'queued', 'sent'].includes(body.status ?? '')) {
      return {
        state: 'failed',
        stateLabel: 'Not sent',
        detail: body.message || `The SMS service did not accept the request (HTTP ${response.status}). No delivery is confirmed.`,
      }
    }
    return {
      state: 'accepted',
      stateLabel: 'Accepted',
      detail: 'The secure SMS service accepted the request. This is not proof that recipients received it.',
      messageId: body.messageId,
    }
  } catch {
    return {
      state: 'failed',
      stateLabel: 'Unavailable',
      detail: 'The background SMS service could not be reached. No message is confirmed as sent; use the manual SMS option if possible.',
    }
  }
}
