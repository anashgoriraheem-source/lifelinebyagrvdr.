/**
 * Builds the emergency message and the one-tap links that hand it to the
 * phone's own dialer and messaging apps. Nothing is sent silently: the
 * person confirms in their messaging app. Server-side SMS/voice via
 * Twilio arrives in a later milestone (see PLAN.md).
 */
import type { AlarmReason, LocationFix } from './types'

export const mapsLink = (f: LocationFix) => `https://maps.google.com/?q=${f.lat.toFixed(6)},${f.lng.toFixed(6)}`

export const clockTime = (t: number) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })

export interface EmergencyProfile {
  name?: string
  age?: string | number
  gender?: string
  bloodType?: string
  conditions?: string
  allergies?: string
  medications?: string
}

const profileValue = (value: unknown) => {
  if (typeof value !== 'string' && typeof value !== 'number') return ''
  const clean = String(value).trim()
  return !clean || /^not provided$/i.test(clean) ? '' : clean
}

/** Always build alerts from the user's saved profile, never demo/fixture identity data. */
export function getEmergencyProfile(): EmergencyProfile {
  if (typeof window === 'undefined') return {}
  try {
    const raw = window.localStorage.getItem('aapda-setu-emergency-profile')
    if (!raw) return {}
    const saved = JSON.parse(raw) as EmergencyProfile
    if (!saved || typeof saved !== 'object' || Array.isArray(saved)) return {}
    // Read only the saved, user-entered profile. Never fall back to fixture/demo patient data.
    return {
      name: profileValue(saved.name), age: profileValue(saved.age), gender: profileValue(saved.gender),
      bloodType: profileValue(saved.bloodType), conditions: profileValue(saved.conditions),
      allergies: profileValue(saved.allergies), medications: profileValue(saved.medications),
    }
  } catch {
    return {}
  }
}

export function buildSosMessage(reason: AlarmReason | null, fix: LocationFix | null, opts: { test?: boolean } = {}) {
  const p = getEmergencyProfile()
  const name = profileValue(p.name) || 'Patient details unavailable'
  const age = profileValue(p.age)
  const rawBloodType = profileValue(p.bloodType)
  const bloodType = /^(unknown|not sure|not provided)$/i.test(rawBloodType) ? '' : rawBloodType
  const gender = profileValue(p.gender)
  const identity = [age, gender, bloodType ? `blood ${bloodType}` : ''].filter(Boolean).join(', ')
  const lines = [
    `${opts.test ? '[TEST — no action needed] ' : ''}EMERGENCY: ${name}${identity ? ` (${identity})` : ''} needs help.`,
    reason ? `Reason: ${reason.label} — ${reason.reading} at ${clockTime(Date.now())}.` : 'Reason: SOS pressed.',
    fix
      ? `Location: ${mapsLink(fix)} (±${Math.round(fix.accuracy)} m, fix time ${new Date(fix.at).toLocaleString()}; ${Math.max(0, Math.round((Date.now() - fix.at) / 1000))} sec old)`
      : 'Location: unavailable — please state your address when calling.',
  ]
  const conditions = profileValue(p.conditions)
  const allergies = profileValue(p.allergies)
  const medications = profileValue(p.medications)
  if (conditions || allergies || medications) {
    lines.push(`Conditions: ${conditions || 'Not provided'}. Allergies: ${allergies || 'Not provided'}. Meds: ${medications || 'Not provided'}.`)
  }
  lines.push('Emergency alert prepared by Aapda Setu. If you receive this, please contact the person and verify the situation.')
  return lines.join('\n')
}

// Emergency-directory entries sometimes list alternatives (e.g. `112 / 119`) or
// mobile notes in parentheses. Never concatenate those digits into a fake number.
const primaryPhone = (phone: string) => phone.split(/\s*\/\s*|;|\s+or\s+/i)[0].replace(/\([^)]*\)/g, '')
const digits = (phone: string) => primaryPhone(phone).replace(/[^\d+]/g, '')

const isApple = () => typeof navigator !== 'undefined' && /iPad|iPhone|iPod|Macintosh/.test(navigator.userAgent)

export function smsHref(phones: string[], body: string) {
  const validPhones = phones.map((phone) => digits(phone)).filter((phone) => /^\+?\d{3,15}$/.test(phone))
  if (!validPhones.length) return ''
  const to = validPhones.join(',')
  return `sms:${to}${isApple() ? '&' : '?'}body=${encodeURIComponent(body)}`
}

export const telHref = (phone: string) => {
  const cleaned = digits(phone)
  return /^\+?\d{3,15}$/.test(cleaned) ? `tel:${cleaned}` : ''
}

export function isValidPhone(phone: string) {
  const d = digits(phone)
  return /^\+?\d{3,15}$/.test(d)
}
