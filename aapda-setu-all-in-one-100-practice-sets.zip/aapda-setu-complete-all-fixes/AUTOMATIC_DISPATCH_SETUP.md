# Aapda Setu automatic dispatch — current status and production setup

## What this project now does

- A long-press SOS or countdown expiry opens the dispatch screen.
- The dispatch screen requests background SMS only when `VITE_BACKGROUND_SMS_ENABLED=true`.
- The client reports **Not configured**, **Unavailable**, **Not sent**, or **Accepted**; it never claims delivery based only on a button press.
- Demo mode is isolated: it simulates the flow and does not call or message real people.
- The web interface shows a call queue in the requested order: police → ambulance → the first saved contact with calling enabled. On the web, the user must tap each call and confirm when they return to continue.
- Existing manual SMS links remain available as a fallback; opening the SMS app does not mean the message was sent.

## Why background SMS is not live yet

The browser needs a server-side SMS provider integration. The provider's secret key must never be stored in frontend code or a `VITE_*` variable. The current project does not yet have a production authentication/session system for authorizing dispatch requests, and no provider credentials have been supplied. For that reason the feature is **disabled by default** and no insecure public SMS endpoint has been added.

A production endpoint at `POST /api/emergency/dispatch` must be deployed only after it has:

1. Authenticated the account/device and verified the user consented to the listed recipients.
2. Validated phone numbers and payload size, rate-limited requests, and deduplicated each incident ID.
3. Kept provider credentials server-side (for example, Twilio or an India-focused SMS gateway).
4. Returned a request/queue status and processed provider delivery receipts separately.
5. Supported a test mode that cannot send to real recipients, plus audit logs and a way to revoke consent.
6. Complied with the SMS provider's India registration/template rules where applicable.

Only after that endpoint is implemented and deployed should the deployment set `VITE_BACKGROUND_SMS_ENABLED=true`. A frontend flag alone does not enable SMS; the server endpoint and its credentials are required.

## Why calls cannot be fully automatic from this website

A `tel:` link hands the call to the phone dialler and normally requires a user gesture. Browsers/PWAs cannot reliably start a chain of calls, stay alive in the background, or detect that a phone call ended. The sequence UI therefore asks the person to tap each call and continue after returning. It does not claim a call connected.

For a genuinely automatic Android call workflow, this needs a native Android app (for example, a Capacitor shell with a custom Android plugin or a Kotlin app), explicit runtime permissions and clear consent, foreground/phone-state handling, device-specific testing, and policy/legal review. Android restrictions and emergency-number handling vary; automatic calls to public emergency services must not be enabled until thoroughly tested with a non-emergency test environment and reviewed by qualified people. Never test against real emergency numbers.

## Suggested deployment checklist

- Keep demo mode as the default during development.
- Configure server authentication before enabling any real SMS dispatch.
- Test using only developer-owned test numbers and a provider sandbox.
- Verify saved profile/contacts, GPS-denied behavior, duplicate suppression, cancel behavior, low/no network, and provider failure.
- Verify the provider's delivery receipt separately from the API accepting the request.
- Do not advertise this prototype as a certified emergency-response or medical device.
