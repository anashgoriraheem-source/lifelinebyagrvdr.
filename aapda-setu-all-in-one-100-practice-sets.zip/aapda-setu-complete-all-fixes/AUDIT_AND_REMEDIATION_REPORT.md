# Aapda Setu — remediation audit

## Changes made in this pass

- Rewrote the Safe Journey page to restore a saved timer after reopening, keep its deadline based on a timestamp, clear state when a journey is ended, and optionally show a browser notification while the page is active and permission is granted.
- Added a service-worker-backed offline fallback page with basic emergency guidance. The service worker caches only public static assets and the offline page; it does not cache profiles, messages, or API responses.
- Corrected SOS/countdown copy so it no longer claims that a call or SMS is sent automatically. Added explicit call/SMS handoff and delivery limitations in the response screen.
- Changed the SMS preview label to make clear the message has not been sent yet.
- Improved SMS/tel URL validation and prevented creation of an SMS link when no valid phone numbers are supplied.
- Added location-fix timestamp/age to SOS messages and omitted unknown blood type from the outgoing identity summary.
- Added hide/reveal controls for medical details on the Rescue page and a browser-local data deletion control.
- Added guarded storage access for language, profile, settings and saved area, and validated persisted settings before applying them.
- Removed seeded fake activity log entries on a fresh installation.
- Corrected marketing copy that overstated real wearable readings, automatic dispatch, live alert delivery and confirmed contacts.
- Added a prominent warning that the OTP screen is a demo and is not real identity verification.
- Added `public/offline.html` and `public/sw.js`; the offline page is a fallback, not a complete offline version of the app.

## Verification performed

- TypeScript/TSX syntax transpilation: 43 source files scanned, zero syntax errors.
- ZIP integrity check is performed on the final deliverable.
- A full production build and automated test suite could not be run because dependencies were unavailable in the offline package cache.

## Known issues that cannot honestly be marked fixed by a front-end-only change

- Real email OTP verification needs a secure backend, sender configuration, server-side expiry/rate limits and server-side session handling. The visible demo code is not authentication.
- Remote SMS/voice dispatch, delivery receipts and background journey escalation need a secure backend/provider integration and user consent. `sms:`/`tel:` links only hand off to the phone apps.
- Medical data remains in browser storage for this prototype. Hide/reveal and deletion controls improve screen privacy, but browser storage is not encrypted/authenticated. Production use needs secure server-side storage and access controls.
- Medical QR generation is not implemented in this package; it should be generated locally with a maintained QR library and only after the user chooses exactly which fields to encode.
- The app does not have a production Bluetooth/wearable data adapter. Vital readings in demo mode are simulated.
- Disaster readiness links to official sources but does not ingest a live official feed or send push alerts.
- Offline support is a static emergency fallback only. It does not provide cached profile access, offline maps, live alerts, or background monitoring.
- Emergency-directory numbers and source notes remain a research draft and must be checked with current authorities for each supported country/region before public deployment.
- The app has not been tested on a physical Android device or through a completed production build in this environment.


## Second-pass audit findings

A second scan for unguarded browser storage, misleading dispatch wording, and prototype-vs-production claims found and addressed additional issues: language/area/profile/settings writes are guarded; the area starts blank rather than prefilled with a location; unknown blood type is omitted from SOS identity text; the landing page and demo screen label simulated readings; the contacts page no longer describes SMS as delivered; and the alarm screen warns that configured emergency numbers may need local verification.

The second pass did not remove the production blockers listed above because they require infrastructure, verified data sources, supported hardware, or dependencies that are not available in this environment.


## Additional hardening pass (2026-10-18)

- Fixed SOS message wording that incorrectly said “Sent via Aapda Setu”; the generated message now explicitly says it has **not been sent yet** and requires the user to press Send in their messaging app.
- Fixed emergency-number links that could concatenate alternatives (for example `112 / 119`) into an invalid number. Call links now use the first listed alternative and the contacts page explains this behaviour. Parenthetical notes such as `000 (Mobile 112)` are removed before generating the call link.
- Added locally generated, user-selected medical-ID text export and copy. The user can choose which profile fields to include; medications are off by default. The file is created on-device and is not uploaded by this feature.
- Reduced offline cache size by removing the 2.7 MB siren from precaching and made service-worker installation tolerant of optional static assets failing to cache. Profiles, messages and API responses remain uncached.
- Added SOS helper regression tests covering unsent-message wording, test-message labelling, invalid numbers and alternative-number handling.

### Additional verification

- TypeScript/TSX syntax transpilation: 44 files, 0 syntax errors.
- Service-worker JavaScript syntax check: passed.
- Direct runtime checks of compiled SOS helpers: 7 assertions passed.
- Vitest suite and full production build remain unrun because project dependencies are not installed and the environment could not resolve the required `vite/client` type package.


## Follow-up remediation pass (2026-10-27)

Implemented in the current working source:
- Alarm countdown and dispatched-overlay cleanup now stop GPS tracking when the alarm is cancelled/resolved, while preserving tracking when the countdown transitions into the response screen.
- Call/SMS tap actions no longer turn into green “completed” indicators merely because the phone dialler or messaging app was opened. The UI explicitly says manual SMS requires review and tapping Send. The call-sequence check mark is only advanced by the user confirming return from a call.
- Added broad input-sanity bounds and logical ordering checks for configurable vital thresholds, plus sanitization of persisted threshold values loaded from local storage. These are not clinical thresholds or medical advice.
- Added focused unit tests for threshold validation and corrupt persisted settings.

Not completed by this pass: live SMS provider/backend credentials, native Android background calling, authoritative verification of the entire international emergency directory, cross-device backup, clinical review, and a full production build/device test. Those require integrations, external verification, or device/clinical resources.
