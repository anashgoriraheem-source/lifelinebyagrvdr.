# Aapda Setu offline improvements

## Available after the app has been opened online
- On service-worker installation, the app attempts to pre-cache the offline guide and all core routes (home, monitor/Pukar, Saath, rescue, alerts, practice, journey, contacts and profile), plus same-origin JavaScript/CSS/JSON/images/audio as those assets load.
- Pukar uses a bundled local intent engine and first-aid guides; common first-aid questions, status explanations, and SOS guidance can work without a network after the app shell has been cached. It is not a fully generative offline language model. Voice input may still require browser/network support.
- Saath's bundled phrase/model data and helpline directory, practice scenarios, saved profile, emergency contacts, local settings, and journey/readiness notes are local and can work offline in the same browser/device once the app has been installed/cached.
- Same-origin audio assets (including the SOS sound) are cached if they are requested successfully while online. Calling and SMS handoff may still work through the phone if cellular service is available, but Aapda Setu cannot confirm delivery.
- The app shows an offline banner when the browser reports no network.
- External web fonts were removed from the critical path; system-font fallbacks work offline.

## Still requires network, a compatible browser/device, or external services
- First visit / installation of the app and any asset that has not yet been cached.
- Live online maps, place search, and route calculations from external map services. The browser may still provide GPS coordinates without internet, but map tiles/place lookup may not load.
- Official live weather/disaster bulletins linked from the Alerts page.
- Cloud account sync, server-side dispatch, remote push, live contact views, and confirmed SMS delivery; these are not implemented as offline capabilities.
- Voice input depends on browser speech-recognition support and may use an online service; offline speech-to-text is not guaranteed. Text-to-speech depends on installed device voices.
- Real wearable data requires supported hardware, browser permissions, Bluetooth support, and a working device connection. Offline mode does not create missing sensor data.

## Safety and privacy boundaries
- API and email-verification paths are explicitly excluded from service-worker caching.
- The service worker only caches same-origin GET resources and successful app navigations; it does not cache POST requests or third-party responses.
- Offline mode does not send an SOS automatically, guarantee background monitoring, or claim that a call/message was delivered.
- The first offline launch only works after the service worker has installed and the needed app files have been loaded/cached while online. Open the app once online before relying on it offline.

## Automatic emergency dispatch status

The SOS and countdown expiry now show a dispatch-status panel and a police → ambulance → saved-contact call queue. Background SMS is deliberately disabled by default: it needs a secure authenticated server endpoint and SMS-provider credentials. Browser calling remains user-initiated and cannot reliably detect call end. See `AUTOMATIC_DISPATCH_SETUP.md` for the production requirements. Demo mode does not contact real people.
