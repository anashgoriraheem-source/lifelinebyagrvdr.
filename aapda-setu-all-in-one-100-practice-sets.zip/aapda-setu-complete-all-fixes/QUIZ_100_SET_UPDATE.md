# Practice quiz: 10 sets × 10 questions

The Practice route now exposes ten numbered sets, each containing ten questions (100 questions total). Each answer receives immediate feedback and an explanation. Each set ends with a percentage score, a supportive performance note, and a suggestion for what to review. Users can retry a set or move to the next one. The practice route reads the saved `lifeline-language` setting and listens for language-change events; visible strings are passed through the existing approved phrasebook translator.

## Important multilingual limitation

This update does **not** claim that all 100 question prompts, answer choices, and explanations have verified translations in all 18 supported languages. The existing translator is a phrasebook matcher, not a general translation engine, and unknown text remains in its original language. A complete multilingual release requires reviewed translations for every question and answer in all 17 non-English locales, plus native-speaker and first-aid review. Do not use an unreviewed automatic translation as emergency or medical guidance.

## Validation

- 100 questions are exposed to users as 10 sets of 10. The source contains additional reserve question records, but they are not shown in the ten-set interface.
- Each question has three answer options and a valid correct-answer index.
- Score feedback bands: 100%, 90–99%, 80–89%, 70–79%, 60–69%, 40–59%, and below 40%.
- This is educational practice, not certified first-aid training or a medical qualification.
- A full app build/test was not run because dependencies are not installed in this environment.
