# Aapda Setu — all prior project versions merged

This package uses the latest map/search-fix source as its base and preserves the newer safety fixes, dispatch setup, offline improvements, and supporting documentation from the earlier project ZIPs.

## Merged project capabilities and safeguards
- Offline app-shell caching, offline fallback page, offline status and local Pukar/Saath support where data is bundled.
- Dispatch adapter and setup documentation; background SMS is still disabled until a secure endpoint and provider are configured.
- Truthful SMS/call status wording; opening a dialler or SMS composer is not reported as a completed call/message.
- GPS tracking cleanup for cancellation/resolution paths while preserving tracking through countdown-to-dispatch transition.
- Threshold input bounds, logical checks, stored-value sanitization and threshold tests; these are input-safety checks, not clinical validation.
- Map viewport held steady during live GPS updates with a manual recenter control.
- Category-specific nearby search improvements and search documentation.
- Existing Saath/Pukar data, training assets, troubleshooting notes, model card, medical-reference documents and project configuration.
- `.env.example` and Netlify server handler restored from the safety/dispatch version.

## Important limitations
- SMS provider credentials and a secured, authenticated backend must be configured and deployed before background SMS can work.
- Automatic phone calling/escalation is not implemented as a reliable web-only feature; native Android integration and device testing are still required.
- Emergency directory entries and health thresholds have not received full authoritative/clinical validation.
- A full production build and end-to-end device test have not been completed in this environment.
