# Map and nearby-search fixes

## Map behavior
- The embedded OpenStreetMap iframe no longer receives a new URL on every GPS update.
- Its initial viewport is set on the first available location fix, then stays stable while the user pans/zooms.
- The `Recenter map` control intentionally updates the map to the latest GPS fix.
- The coordinate text and freshness indicator continue to update from GPS.

## Nearby categories
- Nearby category search uses OpenStreetMap's Overpass API to find mapped points/areas in an approximately 12 km radius around GPS or a geocoded starting area.
- School, college, university, hospital, pharmacy, police, fire station, petrol pump, courts, bus/rail stations, malls, supermarkets, hotels and landmarks have explicit OSM tag selectors.
- Results are deduplicated and sorted closest-first; up to 100 results are shown in a scrollable list instead of only eight.
- Free-text place/address searches still use Nominatim.

## Limitations
- Results depend on OpenStreetMap coverage and tagging; missing or incorrectly tagged places may not appear.
- Public Overpass/Nominatim services have rate limits and can be unavailable. This is not emergency-critical navigation and results should be checked before relying on them.
- A category search needs GPS or a manually entered starting city/area.
