# Aapda Setu multilingual status

## Fixes in this update
- Kept the 18-language chooser (9 national and 9 international languages).
- Added phrase-level translation inside longer UI sentences, not only exact whole-node matches. Matching uses longest-first approved phrases and Unicode word boundaries; unmatched text, names, readings and numbers are preserved.
- Added translations for the primary navigation labels and the no-device state across all 17 non-English locales.
- Validated the saved language code before restoring it, so stale or unsupported local-storage values fall back to English.
- Preserved the existing language-change event and persistent language selection.

## Important limitations
- This is a phrasebook-based UI translator, not full natural-language translation. Any text not present in the approved phrasebook remains in its original language.
- First-aid guide titles, instructions and warnings, plus some Pukar responses, generated activity messages, country labels and validation errors, are not yet fully translated. Do not assume that selecting a language translates all safety guidance.
- Medical and emergency instructions must be translated and reviewed by fluent speakers with relevant first-aid knowledge before production use. This update intentionally does not machine-translate those instructions.
- The existing DOM translation observer remains a compatibility layer. A full migration to React translation keys is still recommended for long-term reliability.

## Verification
- Added tests for mixed-language UI sentences, preserving numbers and unknown words, and the existing 18-language list.
- Dependency installation timed out in this environment, so Vitest and the production build could not be run here. Run `npm ci`, `npm test`, and `npm run build` before deploying.
