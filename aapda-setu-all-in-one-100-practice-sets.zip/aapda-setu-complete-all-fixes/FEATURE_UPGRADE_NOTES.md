# Aapda Setu feature upgrade

This upgrade adds four navigation destinations:

- **Rescue centre**: saved-profile medical ID, copyable emergency details, response checklist, low-signal fallback advice.
- **Safe journey**: local check-in countdown and journey note. It works while this page is open; it does not run reliably in the background or automatically alert contacts.
- **Disaster readiness**: links to official India weather/disaster/flood information, a locally saved area label, and a preparedness checklist. This is not a live alert feed or push-notification subscription.
- **Simulation lab**: three educational mock scenarios; no real call or message is sent.

The existing monitor, Saath, contacts, profile, SMS composer and multilingual phrase/model assets are retained. The SOS message helper reads only the saved emergency profile and does not fall back to a sample patient identity.

## Production integrations still required

- QR code generation should be implemented locally in the browser with a maintained QR library. Do not send medical profile data to a third-party QR API.
- Background journey monitoring/push alerts require a secure backend, notification permissions, subscription management and delivery monitoring.
- Official hazard alerts require a reliable feed/API, geofencing, freshness labels and a tested notification service.
- Reliable automatic wearable readings require supported device integrations and permissions. Browser support varies.
- Offline support requires a tested service worker/cache strategy and explicit handling for stale information. The current low-signal panel is guidance, not full offline operation.
- SMS/tel links hand control to the phone app; they do not prove message delivery or call completion.
