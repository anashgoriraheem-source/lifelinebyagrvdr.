# Saath multilingual local intent model

Saath uses a small, locally executed Multinomial Naive Bayes text classifier with character n-grams (2–5 characters) and a multilingual phrase layer. It is not a generative AI model, does not call a cloud AI service, and does not dispatch responders.

## Training coverage

- **90,000 synthetic utterances total:** 5,000 generated utterances for each of 18 language options (English, Japanese, Russian, Mandarin Chinese, Italian, French, German, Korean, Arabic, Hindi, Punjabi, Kannada, Urdu, Malayalam, Marathi, Gujarati, Odia, and Assamese).
- **16 intent classes:** roadside fuel/breakdown, medical emergency, fire/gas, road crash, poisoning, cyber fraud, women's safety, mental-health support, animal rescue, railway help, electricity, water, telecom, banking, child safety, and disaster support.
- Includes native-script seed phrases, some romanized/colloquial variants, sentence wrappers, context variations, and selected spelling-noise variants.
- The generated corpus is available at `training-data/saath-multilingual-90k.jsonl`; the reproducible generator is `scripts/train_saath_multilingual.py`.

## Test results

See `SAATH_MULTILINGUAL_TRAINING_REPORT.txt` for the split report and hand-written smoke checks. The current synthetic random holdout score is approximately 98%; this split can contain highly similar template variants and is **not** a real-world accuracy estimate. The 36-example hand-written smoke set reached 36/36 with the hybrid phrase layer plus classifier, and 34/36 with the classifier alone. These are small regression checks, not independent validation.

## Important limitations

- The scenarios are synthetic and generated from a limited phrase bank; 5,000 rows per language do not mean 5,000 independently authored meanings.
- Native-speaker review is still needed, especially for translations, colloquial speech, and regional dialects. This is not exhaustive dialect coverage.
- The model is not clinically validated, not a safety-certified dispatcher, and may misclassify unfamiliar, mixed-language, or ambiguous descriptions.
- Helpline entries and numbers in the directory are not independently verified. Confirm current numbers and coverage before launch.
- Never rely on Saath for triage in immediate danger; call the local emergency number (112 in India) directly.

## Reproduce training

From the project root, install Python dependencies (`scikit-learn`) and run:

```bash
python scripts/train_saath_multilingual.py
```

The script evaluates a stratified 80/20 split, then fits the deployment model on all 90,000 generated utterances. It rewrites the model, phrase lexicon, training dataset, and report.
