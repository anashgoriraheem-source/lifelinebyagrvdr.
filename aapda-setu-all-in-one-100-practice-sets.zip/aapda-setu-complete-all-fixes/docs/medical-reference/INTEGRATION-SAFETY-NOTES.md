# Aapda Setu medical reference integration notes

The two supplied PDFs are included as source references, not as an unreviewed prescription database.

## Safe assistant behaviour
- Prioritise local emergency services for life-threatening symptoms; never let voice playback delay calling for help.
- Do not diagnose, prescribe, recommend starting/stopping prescription medicines, or calculate an individual's medication dose.
- For medication questions, give general purpose and key cautions only; advise checking the package leaflet and asking a pharmacist/clinician. For children, pregnancy, chronic illness, allergies, or multiple medicines, recommend professional advice.
- Antibiotics must not be started from chatbot advice. Aspirin and other medicines in suspected heart attack/stroke situations require careful, jurisdiction-appropriate guidance; do not issue blanket instructions.
- Do not present PDF dosing snippets as universally applicable. They may omit contraindications, formulations, local labeling, and patient-specific factors.
- Emergency numbers are country-specific. Use the app's selected country/verified emergency directory rather than hard-coding numbers from a PDF.

## Source material
- `Master_Medication_Reference_Guide.pdf`
- `Comprehensive_Emergency_First_Aid_Guide.pdf`

These references should be clinically reviewed and checked against current official guidance before production use. The built-in first-aid guides remain the operational source for step-by-step responses until that review is completed.
