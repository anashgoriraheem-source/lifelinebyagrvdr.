# Language fix notes

This update improves the existing phrasebook translator. It now replaces approved phrases inside longer UI strings, using longest-first matching and Unicode word boundaries. Unknown text, personal names and numeric values remain unchanged. The language selector validates persisted values and falls back to English for unsupported values.

The application still does not have complete natural-language coverage. In particular, first-aid guide content and some Pukar responses require careful translation and human review before they can safely be presented as translated medical guidance.

Before deployment, run `npm ci`, `npm test`, and `npm run build`, then test every locale on Android and desktop, including RTL layout for Arabic and Urdu.
