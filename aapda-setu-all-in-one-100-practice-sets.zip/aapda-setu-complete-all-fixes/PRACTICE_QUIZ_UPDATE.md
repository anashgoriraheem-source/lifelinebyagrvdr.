# Practice quiz update

The Practice route now contains 36 scenario questions in seven categories: First aid, Fire safety, Floods, Earthquakes, Road safety, Weather, and Preparedness. It includes category filtering, per-question feedback and explanations, a progress bar, final score, and replay. The scenarios are educational and do not trigger calls or SOS alerts.

## Validation and limitations

- The embedded question bank was parsed and checked: 36 entries, each with three options and a valid answer index.
- A full app build was not run because dependencies are not installed and the package registry was unavailable in offline mode.
- The quiz's new question text is authored in English. The existing phrase-based translation runtime only translates phrases present in its phrasebook, so these new quiz strings are not yet fully localized across all 18 languages. They should not be represented as fully translated until reviewed translations are added for every locale.
- Safety content is general education, not medical training. Emergency instructions should be reviewed against local official guidance and qualified first-aid sources before public release.
